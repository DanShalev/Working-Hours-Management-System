/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkNumbers(text_input) {
    var letters = /^[0-9]*$/;
    return (letters.test(text_input));
}

/*------------------ADD ROLE VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var role_capacity=document.forms["edit_role_form"]["role_capacity"].value;
    
    /*=======================role_capacity===============================*/
    //IF role_capacity EMPTY:
    if (role_capacity==null || role_capacity=='') { 
	    	$("#sp_err3").addClass("help-block help-block_style").text("הזן מספר תקנים.");
	    	
	    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg3").addClass("has-error has-feedback");
	        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF role_capacity NOT NUMBERS
    else if (!checkNumbers(role_capacity)) { 
	    	$("#sp_err3").addClass("help-block help-block_style").text("מספר התקנים יכולה להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg3").addClass("has-error has-feedback");
	        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF role_capacity>5000
    else if (+role_capacity>5000) { 
		$("#sp_err3").addClass("help-block help-block_style").text("מספר התקנים לא יכול להיות גדול מ5000.");
		
		if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg3").addClass("has-error has-feedback");
			$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    
    //IF role_capacity<occupied_capacity
    else if (+role_capacity<occupied_capacity) { 
		$("#sp_err3").addClass("help-block help-block_style").text("מספר התקנים לא יכול להיות קטן ממספר התקנים המאויישים (" +
				occupied_capacity + ").");
		
		if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg3").addClass("has-error has-feedback");
			$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg3").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg3").removeClass("has-error has-feedback");
	        	$("#sp3").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err3").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg3").addClass("has-success has-feedback");
	    	$("#sp3").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
   
	return form_submit;
}
