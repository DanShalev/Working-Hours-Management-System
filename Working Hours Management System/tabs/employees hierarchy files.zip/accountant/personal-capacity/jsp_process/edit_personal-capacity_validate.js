/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkTextAndNumbers(text_input) {
    var letters = /^[0-9a-zA-Z]+$/;
    return (letters.test(text_input));
}
function checkNumbers(text_input) {
    var letters = /^[0-9]*$/;
    return (letters.test(text_input));
}
function checkFloatNumbers(text_input) {
    var letters = /^(?:[1-9]\d*|0)?(?:\.\d+)?$/;
    return (letters.test(text_input));
}
function checkText(text_input) {
    var letters = /^[אבגדהוזחטיכלמנסעפצקרשתץףןם a-zA-Z]+$/;
    return (letters.test(text_input));
}
function birthDate(text_input) {
    var date = /^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
    return (date.test(text_input));
}
function checkEmail(text_input) {
    var date = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    return (date.test(text_input));
}
/*------------------OTHER FUNCTIONS----------------------------------------*/
function generatePassword() {
	var pass = Math.floor((Math.random() * 100) + 1);
	$('#password_field').val("Password" + pass);
}

/*------------------ADD USER VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var salary=document.forms["edit_user_form"]["s2"].value;

    /*=========================salary===============================*/
    //IF salary NOT NUMBERS
    if (!checkFloatNumbers(salary)) { 
	    	$("#sp_err8").addClass("help-block help-block_style").text("שכר יכול להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg8").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg8").addClass("has-error has-feedback");
	        	$("#sp8").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF salary<0 && >100000
    else if (+salary<0 || +salary>1000000) { 
		$("#sp_err8").addClass("help-block help-block_style").text("שכר חייב להיות בטווח 0-1000000.");
		
		if (!$("#fg8").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg8").addClass("has-error has-feedback");
			$("#sp8").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg8").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg8").removeClass("has-error has-feedback");
	        	$("#sp8").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err8").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	if (salary!=null && salary!='') {
		    	$("#fg8").addClass("has-success has-feedback");
		    	$("#sp8").addClass("glyphicon glyphicon-ok form-control-feedback");
	    	}
	    	
	    	//ADD LEADING ZERO TO .123 (float without leading zero)
	    	if (salary.charAt(0) == '.') {
	    		$("#s2").val("0"+salary);
	    	}
    }
    
    /*=========================avilable_capacity CHECK===============================*/
    //SELECT VALIDATION
    var false_capacity = false;
    var none_AlsoChosen = false;
	var x = document.getElementById("select_role");
	//CHECK IF 'NONE' & OTHER ROLE WERE SELECTED
	var none_chosen = false;
	for (var i = 0; i < x.options.length; i++) {
	     if(x.options[i].selected == true) {
	    	 if (x.options[i].value == "none")
	    		 none_chosen = true;
	    	 else if (none_chosen == true)
	    		 none_AlsoChosen = true;
	      }
	  }
	//CHECK IF !CHECKBOX & 0 CAPACITY ROLE WERE SELCTED
	  for (var i = 0, count = 0; i < x.options.length; i++) { //IF available_capacity = 0 && CHECKBOX unchecked
	     if(x.options[i].selected == true && x.options[i].value != "none" 
	    	 && x.options[i].getAttribute("data-available_capacity") == "0") {
	    	 if ($("#no_capacity_checkbox" + count).prop('checked') == false) {
	    		 false_capacity = true;
	    	 }
	    	 count++;
	      }
	  }
	  //NONE + ROLE SELCTED MSG
	  if (none_AlsoChosen == true) {
		  $("#sp_err9").addClass("help-block help-block_style").text('לא ניתן לבחור "ללא תפקיד" ביחד עם תפקיד נוסף.');
	    	
	    	if (!$("#fg9").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg9").addClass("has-error has-feedback");
	    	}
	  }
	  //CHECKBOX UNCHECKED & CAOACITY 0 MSG
	  else if (false_capacity == true) { 
    	//CHANGE COLOR
    	$("#sp_err9").addClass("help-block help-block_style").text("לא ניתן לבחור תפקיד עם 0 תקנים פנויים, אלא אם כן הוא עובד בתפקיד ללא תקן.");
    	
    	if (!$("#fg9").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg9").addClass("has-error has-feedback");
    	}
    	form_submit = false;
	    	
    } else {
	    	if ($("#fg9").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg9").removeClass("has-error has-feedback");
	        	$("#sp_err9").removeClass("help-block help-block_style").text("");
	    	}
    }
	return form_submit;
}