/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkTextAndNumbers(text_input) {
    var letters = /^[0-9a-zA-Z]+$/;
    return (letters.test(text_input));
}
function checkNumbers(text_input) {
    var letters = /^[0-9]*$/;
    return (letters.test(text_input));
}
function checkFloatNumbers(text_input) {
    var letters = /^(?:[1-9]\d*|0)?(?:\.\d+)?$/;
    return (letters.test(text_input));
}
function checkText(text_input) {
    var letters = /^[אבגדהוזחטיכלמנסעפצקרשתץףןם a-zA-Z]+$/;
    return (letters.test(text_input));
}
function birthDate(text_input) {
    var date = /^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
    return (date.test(text_input));
}
function checkEmail(text_input) {
    var date = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    return (date.test(text_input));
}
/*------------------OTHER FUNCTIONS----------------------------------------*/
function generatePassword() {
	var pass = Math.floor((Math.random() * 100) + 1);
	$('#password_field').val("Password" + pass);
}

/*------------------ADD USER VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var first_name=document.forms["add_user_form"]["first_name"].value;
	var last_name=document.forms["add_user_form"]["last_name"].value;
	var id_number=document.forms["add_user_form"]["id_number"].value;
	var birth_date=document.forms["add_user_form"]["birth_date"].value;
	var email=document.forms["add_user_form"]["email"].value;
	var password=document.forms["add_user_form"]["password_field"].value;
	var job_description=document.forms["add_user_form"]["job_description"].value;
	var salary=document.forms["add_user_form"]["s2"].value;
	
	/*=======================first_name===============================*/
	//IF first_name EMPTY:
    if (first_name==null || first_name=='') { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן שם פרטי.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    } 
    //IF first_name NOT LETTERS
    else if (!checkText(first_name)) { 
    	$("#sp_err1").addClass("help-block help-block_style").text("שם פרטי יכול להכיל אותיות בלבד.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg1").addClass("has-error has-feedback");
        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF first_name<2 && >20
    else if (first_name.length<2 || first_name.length>20) { 
		$("#sp_err1").addClass("help-block help-block_style").text("שם פרטי חייב להכיל 2-20 תווים.");
		
		if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg1").addClass("has-error has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    //GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================last_name===============================*/
	//IF last_name EMPTY:
    if (last_name==null || last_name=='') { 
	    	$("#sp_err2").addClass("help-block help-block_style").text("הזן שם משפחה.");
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF last_name NOT LETTERS
    else if (!checkText(last_name)) { 
	    	$("#sp_err2").addClass("help-block help-block_style").text("שם משפחה יכול להכיל אותיות בלבד.");
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    } 
    //IF last_name<2 && >20
    else if (last_name.length<2 || last_name.length>20) { 
		$("#sp_err2").addClass("help-block help-block_style").text("שם משפחה חייב להכיל 2-20 תווים.");
		
		if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg2").addClass("has-error has-feedback");
			$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg2").removeClass("has-error has-feedback");
	        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg2").addClass("has-success has-feedback");
	    	$("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================id_number===============================*/
	//IF id_number EMPTY:
    if (id_number==null || id_number=='') { 
	    	$("#sp_err3").addClass("help-block help-block_style").text("הזן תעודת זהות.");
	    	
	    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg3").addClass("has-error has-feedback");
	        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF id_number NOT LETTERS
    else if (!checkNumbers(id_number)) { 
	    	$("#sp_err3").addClass("help-block help-block_style").text("תעודת זהות יכולה להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg3").addClass("has-error has-feedback");
	        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF id_number!=9
    else if (id_number.length!=9) { 
		$("#sp_err3").addClass("help-block help-block_style").text("תעודת זהות חייבת להכיל 9 תווים.");
		
		if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg3").addClass("has-error has-feedback");
			$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    } 
    //ID UNIQUE OR GREEN MSG
    else  { 
    	//IF id_number = UNIQUE FROM DB
    	$.ajaxSetup({async: false});
    	$.post("tabs/system_admin/manage-users/jsp_process/check_id.jsp",{id: id_number},
    			  function(data,status) { //AFTER AJAX FUNCTIONS
    		var idError = $.trim(data);
    		
    		//IF - NOT OK
    		 if (idError == "true") { //true - ID EXIST, NOT UNIQUE
	    		 $("#sp_err3").addClass("help-block help-block_style").text("תעודת הזהות קיימת במאגר. אנא הזן תעודת זהות שונה.");
	    			
	    			if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    				$("#fg3").addClass("has-error has-feedback");
	    				$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    			}
	    			form_submit = false;
    		 }
    		//ELSE - ID IS OK, GREEN MSG
    		 else {	
    			 if ($("#fg3").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		    		$("#fg3").removeClass("has-error has-feedback");
    		        	$("#sp3").removeClass("glyphicon glyphicon-remove form-control-feedback");
    		        	$("#sp_err3").removeClass("help-block help-block_style").text("");
    		    	}
    		    	//ADD OK CLASS
    		    	$("#fg3").addClass("has-success has-feedback");
    		    	$("#sp3").addClass("glyphicon glyphicon-ok form-control-feedback");
    		 }
    	});
    }
    
    /*=======================birth_date===============================*/
    var year = birth_date.split("-"); //year[0] = form year
    var currentTime = new Date();
    var currentYear = currentTime.getFullYear();
	//IF birth_date EMPTY:
    if (birth_date==null || birth_date=='') { 
	    	$("#sp_err4").addClass("help-block help-block_style").text("הזן תאריך לידה.");
	    	
	    	if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg4").addClass("has-error has-feedback");
	        	$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF birth_date NOT BIRTHDATE
    else if (!birthDate(birth_date)) { 
	    	$("#sp_err4").addClass("help-block help-block_style").text("תאריך לידה לא תקין. (yyyy-mm-dd)");
	    	
	    	if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg4").addClass("has-error has-feedback");
	        	$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF formYear < 1900 && formYear > currentYear
    else if (year[0] < 1900 || year[0] > currentYear) { 
	    	$("#sp_err4").addClass("help-block help-block_style").text('הזן שנת לידת בטווח 1900-' + currentYear + '.');
	    	
	    	if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg4").addClass("has-error has-feedback");
	        	$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg4").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg4").removeClass("has-error has-feedback");
	        	$("#sp4").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err4").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg4").addClass("has-success has-feedback");
	    	$("#sp4").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================email===============================*/
	//IF email EMPTY:
    if (email==null || email=='') { 
	    	$("#sp_err5").addClass("help-block help-block_style").text("הזן דואר אלקטרוני.");
	    	
	    	if (!$("#fg5").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg5").addClass("has-error has-feedback");
	        	$("#sp5").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF email NOT VALID
    else if (!checkEmail(email)) { 
	    	$("#sp_err5").addClass("help-block help-block_style").text("הזן כתובת דואר אלקטרוני תקינה. example@mail.com");
	    	
	    	if (!$("#fg5").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg5").addClass("has-error has-feedback");
	        	$("#sp5").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    else {
    	if ($("#fg5").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg5").removeClass("has-error has-feedback");
        	$("#sp5").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err5").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg5").addClass("has-success has-feedback");
    	$("#sp5").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    /*=======================password===============================*/
	//IF password EMPTY:
    if (password==null || password=='') { 
	    	$("#sp_err6").addClass("help-block help-block_style").text("הזן סיסמת משתמש.");
	    	
	    	if (!$("#fg6").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg6").addClass("has-error has-feedback");
	        	$("#sp6").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    } 
    //IF password IS NOT NUMBERS AND LETTERS:
    else if (!checkTextAndNumbers(password)) {
    	$("#sp_err6").addClass("help-block help-block_style").text("הסיסמה יכולה להכיל אותיות לועזיות ומספרים בלבד.");
    	
    	if (!$("#fg6").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg6").addClass("has-error has-feedback");
        	$("#sp6").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF password IS NOT 5-16 CHARS:
    else if (password.length<5 || password.length>16) {
    	$("#sp_err6").addClass("help-block help-block_style").text("הסיסמה חייבת להכיל 5-16 תווים.");
    	
    	if (!$("#fg6").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg6").addClass("has-error has-feedback");
        	$("#sp6").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
        form_submit = false;
    }
    else {
    	if ($("#fg6").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg6").removeClass("has-error has-feedback");
        	$("#sp6").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err6").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg6").addClass("has-success has-feedback");
    	$("#sp6").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    /*=======================job_description===============================*/
    //IF job_description>225
    if (job_description.length>225) { 
		$("#sp_err7").addClass("help-block help-block_style").text("תיאור המשרה יכול להכיל עד 225 תווים.");
		
		if (!$("#fg7").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg7").addClass("has-error has-feedback");
			$("#sp7").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg7").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg7").removeClass("has-error has-feedback");
	        	$("#sp7").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err7").removeClass("help-block help-block_style").text("");
	    	}
    }
    /*=========================salary===============================*/
    //IF salary NOT NUMBERS
    if (!checkFloatNumbers(salary)) { 
	    	$("#sp_err8").addClass("help-block help-block_style").text("שכר יכול להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg8").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg8").addClass("has-error has-feedback");
	        	$("#sp8").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF salary<0 && >100000
    else if (+salary<0 || +salary>1000000) { 
		$("#sp_err8").addClass("help-block help-block_style").text("שכר חייב להיות בטווח 0-1000000.");
		
		if (!$("#fg8").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg8").addClass("has-error has-feedback");
			$("#sp8").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg8").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg8").removeClass("has-error has-feedback");
	        	$("#sp8").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err8").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	if (salary!=null && salary!='') {
		    	$("#fg8").addClass("has-success has-feedback");
		    	$("#sp8").addClass("glyphicon glyphicon-ok form-control-feedback");
	    	}
	    	
	    	//ADD LEADING ZERO TO .123 (float without leading zero)
	    	if (salary.charAt(0) == '.') {
	    		$("#s2").val("0"+salary);
	    	}
    }
    
    /*=========================avilable_capacity CHECK===============================*/
    //SELECT VALIDATION
    var false_capacity = false;
    var none_AlsoChosen = false;
	var x = document.getElementById("select_role");
	//CHECK IF 'NONE' & OTHER ROLE WERE SELECTED
	var none_chosen = false;
	for (var i = 0; i < x.options.length; i++) {
	     if(x.options[i].selected == true) {
	    	 if (x.options[i].value == "none")
	    		 none_chosen = true;
	    	 else if (none_chosen == true)
	    		 none_AlsoChosen = true;
	      }
	  }
	//CHECK IF !CHECKBOX & 0 CAPACITY ROLE WERE SELCTED
	  for (var i = 0, count = 0; i < x.options.length; i++) { //IF available_capacity = 0 && CHECKBOX unchecked
	     if(x.options[i].selected == true && x.options[i].value != "none" 
	    	 && x.options[i].getAttribute("data-available_capacity") == "0") {
	    	 if ($("#no_capacity_checkbox" + count).prop('checked') == false) {
	    		 false_capacity = true;
	    	 }
	    	 count++;
	      }
	  }
	  //NONE + ROLE SELCTED MSG
	  if (none_AlsoChosen == true) {
		  $("#sp_err9").addClass("help-block help-block_style").text('לא ניתן לבחור "ללא תפקיד" ביחד עם תפקיד נוסף.');
	    	
	    	if (!$("#fg9").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg9").addClass("has-error has-feedback");
	    	}
	  }
	  //CHECKBOX UNCHECKED & CAOACITY 0 MSG
	  else if (false_capacity == true) { 
    	//CHANGE COLOR
    	$("#sp_err9").addClass("help-block help-block_style").text("לא ניתן לבחור תפקיד עם 0 תקנים פנויים, אלא אם כן הוא עובד בתפקיד ללא תקן.");
    	
    	if (!$("#fg9").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg9").addClass("has-error has-feedback");
    	}
    	form_submit = false;
	    	
    } else {
    	if ($("#fg9").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg9").removeClass("has-error has-feedback");
        	$("#sp_err9").removeClass("help-block help-block_style").text("");
    	}
    }
    
	return form_submit;
}
