/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkNumbers(text_input) {
    var letters = /^[0-9]*$/;
    return (letters.test(text_input));
}
function checkText(text_input) {
    var letters = /^[אבגדהוזחטיכלמנסעפצקרשתץףןם a-zA-Z]*$/;
    return (letters.test(text_input));
}

/*------------------ADD USER VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var all_null = false;
	var id_number=document.forms["search_user"]["id_number"].value;
	var first_name=document.forms["search_user"]["first_name"].value;
	var last_name=document.forms["search_user"]["last_name"].value;
	
	/*=======================EMPTY FIELDS===============================*/
    if((id_number==null || id_number=='') && (first_name==null || first_name=='') && (last_name==null || last_name=='')) {
    	all_null = true;

    	$("#sp_err3").addClass("help-block help-block_style").text("יש להזין ערכים באחד השדות לפחות.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    	$("#fg1").addClass("has-error has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    	$("#fg2").addClass("has-error has-feedback");
	    	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    	$("#fg3").addClass("has-error has-feedback");
	    	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    
	/*=======================id_number===============================*/
    //IF id_number NOT LETTERS
    if (!checkNumbers(id_number)) { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("תעודת זהות יכולה להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF id_number!=9
    else if (id_number.length>9) { 
		$("#sp_err1").addClass("help-block help-block_style").text("תעודת זהות יכולה להכיל עד 9 תווים.");
		
		if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg1").addClass("has-error has-feedback");
			$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else if (all_null != true) {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
    }
    
	/*=======================first_name===============================*/
    //IF first_name NOT LETTERS
    if (!checkText(first_name)) { 
    	$("#sp_err2").addClass("help-block help-block_style").text("שם פרטי יכול להכיל אותיות בלבד.");
    	
    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg2").addClass("has-error has-feedback");
        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF last_name>20
    else if (first_name.length>20) { 
		$("#sp_err2").addClass("help-block help-block_style").text("שם פרטי לא יכול להכיל יותר מ20 תווים.");
		
		if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg2").addClass("has-error has-feedback");
	    	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    //GREEN MSG
    else if (all_null != true) {
    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg2").removeClass("has-error has-feedback");
        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err2").removeClass("help-block help-block_style").text("");
    	}
    }
    
    /*=======================last_name===============================*/
    //IF last_name NOT LETTERS
    if (!checkText(last_name)) { 
    	$("#sp_err3").addClass("help-block help-block_style").text("שם פרטי יכול להכיל אותיות בלבד.");
    	
    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg3").addClass("has-error has-feedback");
        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF last_name>20
    else if (last_name.length>20) { 
		$("#sp_err3").addClass("help-block help-block_style").text("שם משפחה לא יכול להכיל יותר מ20 תווים.");
		
		if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg3").addClass("has-error has-feedback");
	    	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    //GREEN MSG
    else if (all_null != true) {
    	if ($("#fg3").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg3").removeClass("has-error has-feedback");
        	$("#sp3").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err3").removeClass("help-block help-block_style").text("");
    	}
    }
    	
    return form_submit;
}

/*------------------SEARCH FIELDS FUNCTION----------------------------------------*/
$(function() {
	$('#search_by_group').change(function() {
	    var selected = $(':selected', this);
	    var optgroup_name = selected.parent().attr('name');
	    $('#search_by_group').attr('name', optgroup_name);
	});
});