$(function() { // Handler for .ready() called.
	//------------------------CHOOSE USER HANDLER----------------------------------------
	$("#select_user_type").change(function() {
		//CHANGE FIELDS BY SELECTED USER TYPE
		if ($(this).val() == "hourly_worker" || $(this).val() == "coordinator") {
			$("#user_type_office").show();
			$("#choose_office_label").text("משרד ממונה");
		} else if ($(this).val() == "office_manager") {
			$("#user_type_office").show();
			$("#choose_office_label").text("משרד לניהול");
		} else { //val() = president, accountant
			$("#user_type_office").hide();
		}
	});
	//------------------------------CHOOSE ROLE HANDLER---------------------------------
	$("#no_capacity_checkbox_div").hide();
	$("#choose_role_help_block").hide();
	
	$("#select_role").change(function() {
		if ($(this).val() == "none") { //"NONE" ROLE WAS SELCTED
			$("#no_capacity_checkbox_div").hide();
			$("#choose_role_help_block").hide();
		}
		else { //ROLE WAS SELCTED
			$("#no_capacity_checkbox_div").show();
			$("#choose_role_help_block").show();
		}
	});
	
	//APPLY MULTIPULE ROLES OPTION
	$("#more-less_roles").click(function() {
		if ($('#select_role').attr('multiple') !== undefined) { //attribute exists
			$('#select_role').removeAttr("multiple");
			$("#more-less_roles").html("<br>* לבחירת יותר מתפקיד אחד, לחץ כאן.");
			$("#more_roles_help").html("* העובד יהיה תחת המשרד הממונה שהוזן (אם יש), ללא קשר למשרד אליו משוייך התפקיד.");
			$("#select_role").trigger("change");
		} else {
			$('#select_role').attr("multiple","");
			$("#more-less_roles").html("<br>* לבחירת תפקיד אחד בלבד, לחץ כאן.");
			$("#more_roles_help").html("* העובד יהיה תחת המשרד הממונה שהוזן (אם יש), ללא קשר למשרד אליו משוייך התפקיד. <br>* ניתן לבחור עד 5 תפקידים לעובד, בעזרת לחיצה על CTRL וסימון התפקידים.");
			$("#select_role").trigger("change");
		}
	});
	
	//MAKE SURE NO MORE THEN 5 SELCTED
	$("#select_role").on("click", "option", function (event) {
	    if (5 <= $(this).siblings(":selected").length) {
	        $(this).removeAttr("selected");
	    }
	});
	//------------------------------CHECKBOX HANDLER---------------------------------
	$("#checkbox_div1").hide();
	$("#checkbox_div2").hide();
	$("#checkbox_div3").hide();
	$("#checkbox_div4").hide();
	$("#select_role").change(function(/*e*/) {
		//CHECK SELECTIONS ON EACH SELECT CHANGE
		$("#checkbox_div1").hide();
		$("#checkbox_div2").hide();
		$("#checkbox_div3").hide();
		$("#checkbox_div4").hide();
		var x = document.getElementById("select_role");
		  for (var i = 0, count = 0; i < x.options.length; i++) {
		     if(x.options[i].selected == true && x.options[i].value != "none"){
		    	 var office_name = x.options[i].getAttribute("name");
		    	 $("#checkbox" + count).text('עובד בתפקיד "'+ office_name +'" ללא תקן.');
		    	 $("#no_capacity_checkbox" + count).attr('checked', false);
		    	 $("#checkbox_div" + count).show(); //NOTE: "checkbox_div0" does not exists - always show();
		    	 count++;
		      }
		  }
	});
});
