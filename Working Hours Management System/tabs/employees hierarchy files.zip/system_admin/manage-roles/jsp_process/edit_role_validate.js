/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkNumbers(text_input) {
    var letters = /^[0-9]*$/;
    return (letters.test(text_input));
}
function checkText(text_input) {
    var letters = /^[אבגדהוזחטיכלמנסעפצקרשתץףךןם1234567890 a-zA-Z]+$/;
    return (letters.test(text_input));
}

/*------------------ADD ROLE VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var role_name=document.forms["edit_role_form"]["role_name"].value;
	var role_description=document.forms["edit_role_form"]["role_description"].value;
	var role_capacity=document.forms["edit_role_form"]["role_capacity"].value;
	var monthly_hours=document.forms["edit_role_form"]["monthly_hours"].value;
	var monthly_hours_summer=document.forms["edit_role_form"]["monthly_hours_summer"].value;
	
	/*=======================role_name===============================*/
	//IF role_name EMPTY:
    if (role_name==null || role_name=='') { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן שם תפקיד.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    } 
    //IF role_name NOT LETTERS
    else if (!checkText(role_name)) { 
    	$("#sp_err1").addClass("help-block help-block_style").text("שם התפקיד יכול להכיל אותיות ומספרים בלבד.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg1").addClass("has-error has-feedback");
        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF role_name<2 && >50
    else if (role_name.length<2 || role_name.length>50) { 
		$("#sp_err1").addClass("help-block help-block_style").text("שם התפקיד חייב להכיל 2-50 תווים.");
		
		if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg1").addClass("has-error has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    //GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================role_description===============================*/
    //IF role_description>225
    if (role_description.length>225) { 
		$("#sp_err2").addClass("help-block help-block_style").text("תיאור התפקיד יכול להכיל עד 225 תווים.");
		
		if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg2").addClass("has-error has-feedback");
			$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg2").removeClass("has-error has-feedback");
	        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
    }
    
    /*=======================role_capacity===============================*/
    //IF role_capacity EMPTY:
    if (role_capacity==null || role_capacity=='') { 
	    	$("#sp_err3").addClass("help-block help-block_style").text("הזן מספר תקנים.");
	    	
	    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg3").addClass("has-error has-feedback");
	        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF role_capacity NOT NUMBERS
    else if (!checkNumbers(role_capacity)) { 
	    	$("#sp_err3").addClass("help-block help-block_style").text("מספר התקנים יכולה להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg3").addClass("has-error has-feedback");
	        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF role_capacity>5000
    else if (+role_capacity>5000) { 
		$("#sp_err3").addClass("help-block help-block_style").text("מספר התקנים לא יכול להיות גדול מ5000.");
		
		if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg3").addClass("has-error has-feedback");
			$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    
    //IF role_capacity<occupied_capacity
    else if (+role_capacity<occupied_capacity) { 
		$("#sp_err3").addClass("help-block help-block_style").text("מספר התקנים לא יכול להיות קטן ממספר התקנים המאויישים (" +
				occupied_capacity + ").");
		
		if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg3").addClass("has-error has-feedback");
			$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg3").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg3").removeClass("has-error has-feedback");
	        	$("#sp3").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err3").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg3").addClass("has-success has-feedback");
	    	$("#sp3").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    /*=======================monthly_hours===============================*/
    //IF monthly_hours EMPTY:
    if (monthly_hours==null || monthly_hours=='') { 
	    	$("#sp_err4").addClass("help-block help-block_style").text("הזן מכסת שעות חודשית.");
	    	
	    	if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg4").addClass("has-error has-feedback");
	        	$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF monthly_hours NOT NUMBERS
    else if (!checkNumbers(monthly_hours)) { 
	    	$("#sp_err4").addClass("help-block help-block_style").text("מכסת השעות יכולה להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg4").addClass("has-error has-feedback");
	        	$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF monthly_hours<0 && >100000
    else if (+monthly_hours<0 || +monthly_hours>100000) { 
		$("#sp_err4").addClass("help-block help-block_style").text("מכסת השעות חייבת להיות בטווח 0-100000.");
		
		if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg4").addClass("has-error has-feedback");
			$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg4").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg4").removeClass("has-error has-feedback");
	        	$("#sp4").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err4").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg4").addClass("has-success has-feedback");
	    	$("#sp4").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================monthly_hours_summer===============================*/
    //IF monthly_hours_summer EMPTY:
    if (monthly_hours_summer==null || monthly_hours_summer=='') { 
	    	$("#sp_err5").addClass("help-block help-block_style").text("הזן מכסת שעות חודשית.");
	    	
	    	if (!$("#fg5").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg5").addClass("has-error has-feedback");
	        	$("#sp5").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF monthly_hours NOT NUMBERS
    else if (!checkNumbers(monthly_hours_summer)) { 
	    	$("#sp_err5").addClass("help-block help-block_style").text("מכסת השעות יכולה להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg5").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg5").addClass("has-error has-feedback");
	        	$("#sp5").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF monthly_hours_summer<0 && >100000
    else if (+monthly_hours_summer<0 || +monthly_hours_summer>100000) { 
		$("#sp_err5").addClass("help-block help-block_style").text("מכסת השעות חייבת להיות בטווח 0-100000.");
		
		if (!$("#fg5").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg5").addClass("has-error has-feedback");
			$("#sp5").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg5").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg5").removeClass("has-error has-feedback");
	        	$("#sp5").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err5").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg5").addClass("has-success has-feedback");
	    	$("#sp5").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
	return form_submit;
}
