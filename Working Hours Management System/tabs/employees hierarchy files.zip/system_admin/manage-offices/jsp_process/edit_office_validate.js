/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkNumbers(text_input) {
    var letters = /^[0-9]*$/;
    return (letters.test(text_input));
}
function checkText(text_input) {
    var letters = /^[אבגדהוזחטיכלמנסעפצקרשתץףןךם1234567890  a-zA-Z]+$/;
    return (letters.test(text_input));
}

/*------------------ADD office VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var office_name=document.forms["edit_office_form"]["office_name"].value;
	var office_description=document.forms["edit_office_form"]["office_description"].value;
	
	/*=======================office_name===============================*/
	//IF office_name EMPTY:
    if (office_name==null || office_name=='') { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן שם משרד.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    } 
    //IF office_name NOT LETTERS
    else if (!checkText(office_name)) { 
    	$("#sp_err1").addClass("help-block help-block_style").text("שם המשרד יכול להכיל אותיות ומספרים בלבד.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg1").addClass("has-error has-feedback");
        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF office_name<2 && >50
    else if (office_name.length<2 || office_name.length>50) { 
		$("#sp_err1").addClass("help-block help-block_style").text("שם המשרד חייב להכיל 2-50 תווים.");
		
		if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg1").addClass("has-error has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
    //GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================office_description===============================*/
    //IF office_description>225
    if (office_description.length>225) { 
		$("#sp_err2").addClass("help-block help-block_style").text("תיאור המשרד יכול להכיל עד 225 תווים.");
		
		if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg2").addClass("has-error has-feedback");
			$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg2").removeClass("has-error has-feedback");
	        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
    }
    
	return form_submit;
}
