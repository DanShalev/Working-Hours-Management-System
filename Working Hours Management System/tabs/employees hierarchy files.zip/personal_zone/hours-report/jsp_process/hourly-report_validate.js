function addLeadingZeroInput(elementId) {
	    if ($('#'+elementId).val().length==1) 
	    	$('#'+elementId).val(function(n, current){
	        return "0"+current;
	    }); 
}

function addZ(n) {
	return n<10? '0'+n:''+n;
} //add zero to month for input yyyy-mm

function checkHours(text_input) { //TRUE = STRING OK
	var letters = /^[0-9]{2}$/;
	return (letters.test(text_input) && !(text_input<0 || text_input>23));
}

function checkMinutes(text_input) {
	var letters = /^[0-9]{2}$/;
	return (letters.test(text_input) && !(text_input<0 || text_input>59));
}

/*------------------ADD REPORT VALIDATE----------------------------------------*/
function validateAddHourlyReport() {
	//ADD LEADING ZERO
	addLeadingZeroInput("hourly-form-start-time-mm");
	addLeadingZeroInput("hourly-form-start-time-hh");
	addLeadingZeroInput("hourly-form-end-time-mm");
	addLeadingZeroInput("hourly-form-end-time-hh");
	
	//----------------------------
	
	var form_submit = true;
	var start_hh = $("#hourly-form-start-time-hh").val();
	var start_mm = $("#hourly-form-start-time-mm").val();
	var end_hh = $("#hourly-form-end-time-hh").val();
	var end_mm = $("#hourly-form-end-time-mm").val();
	var hours_description = $("#hourly-form-details").val();
	var hours_start_checked = false;
	var hours_end_checked = false;
	
	//SET TO NULL
	if (!$("#tr_start-hour").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
		$("#tr_start-hour").removeClass("has-error");
	}
	$("#error_msg_add-hourly-report").empty();
    /*=======================start_hours===============================*/
	//IF start_hours EMPTY:
    if (start_hh==null || start_hh=='' || start_mm==null || start_mm=='') { 
	    	$("#error_msg_add-hourly-report").html("<span class='glyphicon glyphicon-remove form-control-feedback'></span> הזן שעת התחלה.<br>");
	    	
	    	if (!$("#tr_start-hour").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#tr_start-hour").addClass("has-error");
	    		$("#td_start").css("color", "#d9534f");
	    	}
	    	form_submit = false;
    }
    //IF start_hours IS hours
    else if (!checkHours(start_hh) || !checkMinutes(start_mm)) { 
	    	$("#error_msg_add-hourly-report").html("<span class='glyphicon glyphicon-remove form-control-feedback'></span> הזן שעת כניסה תקינה (00-59).<br>");
	    	
	    	if (!$("#tr_start-hour").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#tr_start-hour").addClass("has-error");
	    		$("#td_start").css("color", "#d9534f");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#tr_start-hour").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#tr_start-hour").removeClass("has-error");
	    	}
	    	$("#tr_start-hour").addClass("has-success");
	    	$("#td_start").css("color", "#5cb85c");
	    	hours_start_checked = true;
    }
    
    /*=======================end_hours===============================*/
	//IF start_hours EMPTY:
    if (end_hh==null || end_hh=='' || end_mm==null || end_mm=='') { 
	    	$("#error_msg_add-hourly-report").html(function(index, content) {
	    		return content + "<span class='glyphicon glyphicon-remove form-control-feedback'></span> הזן שעת סיום.<br>";
	    	});
	    	
	    	if (!$("#tr_end-hour").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#tr_end-hour").addClass("has-error");
	    		$("#td_end").css("color", "#d9534f");
	    	}
	    	form_submit = false;
    }
    //IF start_hours IS hours
    else if (!checkHours(end_hh) || !checkMinutes(end_mm)) { 
    	$("#error_msg_add-hourly-report").html(function(index, content) {
    		return content + "<span class='glyphicon glyphicon-remove form-control-feedback'></span> הזן שעת סיום תקינה (00-59).<br>";
    	});
	    	
	    	if (!$("#tr_end-hour").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#tr_end-hour").addClass("has-error");
	    		$("#td_end").css("color", "#d9534f");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#tr_end-hour").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#tr_end-hour").removeClass("has-error");
	    	}
	    	$("#tr_end-hour").addClass("has-success");
	    	$("#td_end").css("color", "#5cb85c");
	    	hours_end_checked = true;
    }

    /*=======================hours_start > hours_end===============================*/
    if (hours_start_checked == true && hours_end_checked == true) {
    	if (end_hh<start_hh || (end_hh==start_hh && end_mm<start_mm) || (end_hh==start_hh && end_mm==start_mm)) {
    		$("#error_msg_add-hourly-report").html("<span class='glyphicon glyphicon-remove form-control-feedback'></span> שעת ההתחלה צריכה להקדים את שעת הסיום.<br>");

    		$("#tr_start-hour").addClass("has-error");
    		$("#td_start").css("color", "#d9534f");
    		$("#tr_end-hour").addClass("has-error");
    		$("#td_end").css("color", "#d9534f");
	    	form_submit = false;
    	}
    }
    
    /*=======================hours_description===============================*/
    //IF hours_description>225
    if (hours_description == null || hours_description.trim() == '') {
    	$("#error_msg_add-hourly-report").html(function(index, content) {
    		return content + "<span class='glyphicon glyphicon-remove form-control-feedback'></span> הזן פירוט.<br>";
    	});
	    	
	    	if (!$("#div_details").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#div_details").addClass("has-error");
	    		$("#div_details").css("color", "#d9534f");
	    }
	    form_submit = false;
    } 
  //IF hours_description>225
    else if (hours_description.length>225) { 
    	$("#error_msg_add-hourly-report").html(function(index, content) {
    		return content + "<span class='glyphicon glyphicon-remove form-control-feedback'></span> פירוט הדיווח לא יכול להכיל יותר מ225 תווים.<br>";
    	});
	    	
	    	if (!$("#div_details").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#div_details").addClass("has-error");
	    		$("#div_details").css("color", "#d9534f");
	    }
	    form_submit = false;
    }
	//GREEN MSG
    else {
    	if ($("#div_details").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#div_details").removeClass("has-error");
    	}
    	$("#div_details").addClass("has-success");
    	$("#div_details").css("color", "#5cb85c");
    }

    //REPLACE NEWLINE
    if (form_submit == true) {
    	var text = $(".hours-description-n_script").val();
		text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
		$(".hours-description-n_script").val(text);
    }
	return form_submit;
}

/*------------------ADD MONTHLY REPORT VALIDATE----------------------------------------*/
function validateAddMonthlyReport() {
	var form_submit = true;
	var hours_description = $("#hourly-form-details").val();
	
	//SET TO NULL
	$("#error_msg_add-hourly-report").empty();
    
    /*=======================hours_description===============================*/
    //IF hours_description>225
    if (hours_description == null || hours_description.trim() == '') {
    	$("#error_msg_add-hourly-report").html(function(index, content) {
    		return content + "<span class='glyphicon glyphicon-remove form-control-feedback'></span> הזן פירוט.<br>";
    	});
	    	
	    	if (!$("#div_details").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#div_details").addClass("has-error");
	    		$("#div_details").css("color", "#d9534f");
	    }
	    form_submit = false;
    } 
  //IF hours_description>225
    else if (hours_description.length>225) { 
    	$("#error_msg_add-hourly-report").html(function(index, content) {
    		return content + "<span class='glyphicon glyphicon-remove form-control-feedback'></span> פירוט הדיווח לא יכול להכיל יותר מ225 תווים.<br>";
    	});
	    	
	    	if (!$("#div_details").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#div_details").addClass("has-error");
	    		$("#div_details").css("color", "#d9534f");
	    }
	    form_submit = false;
    }
	//GREEN MSG
    else {
    	if ($("#div_details").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#div_details").removeClass("has-error");
    	}
    	$("#div_details").addClass("has-success");
    	$("#div_details").css("color", "#5cb85c");
    }

    //REPLACE NEWLINE
    if (form_submit == true) {
    	var text = $(".hours-description-n_script").val();
		text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
		$(".hours-description-n_script").val(text);
    }
	return form_submit;
}