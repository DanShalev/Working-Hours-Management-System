function MonthsInputFormController(date, callback ){

    var self = this;
    this.date = date;

    // load template and register callbacks
    preLoad({'inputForm':"tabs/personal_zone/hours-report/calander_script/templates/add_monthly-report.html"}, function(res){
        // initialize the form controller
        self.init(res);

        // inform caller that this object is ready for use
        callback();
    });
    
    /*
     * initiating the form controller
     */
    this.init = function(loaded_res){

        var html = $(loaded_res.inputForm.format({date:this.date}));

        // store subtree in __html__ for use by this.html()
        self.__html__ = html;

        // -----------------------
        // register event emitters
        // -----------------------

        /*/ register on('cancel') event
        (html.find('#monthly-form-cancel-button')).on('click', function(){
        	canceledMonthlyReport();
        });*/

        // register on('save') event
        (html.find('#monthly-form-add-save-button')).on('click', function(){       
        		if(validateAddMonthlyReport()) { //FUNCTION IN hourly-report/jsp_process

        			// load inputs into object & emit event
                    self.details = html.find('#hourly-form-details').val();
                    savedMonthlyReport(self);
                    
                    $('#add_monthly-report_modal').modal('hide');
        		}

        });
    };
    
 	//------------------------FORM INPUT FUNCTIONS----------------------
    function savedMonthlyReport(self) {
    	console.log("saved (monthly report)");
    	var curr_date = self.date.replace('0', '').replace('/', '-');
    	self.date = curr_date;
    	//ADD MONTHLY REPORT INTO DB VIA AJAX
    	var id = ajaxAddMonthlyReport(self);
    	
    	//INSERT MONTHLY REPORT INTO MODEL ARRAY
    	if (!model[curr_date]) //ADD [curr_date] TO model IF NOT EXIST
    		model[curr_date] = [];

    	//PUSH NEW REPORT OBJECT TO model[curr_date]
    	model[curr_date].push({type:'monthly', id: id, date: '0-0-0', status:'unconfirmed', editStatus:'editable', details: self.details});
    	console.log(model[curr_date]);
    	
    	//RELOAD CALANDER
    	window.setCalendar();
    }
    
    //------------------------------------------------------------
    /*
     * return subtree for this form element
     */
    this.html = function(){
        return this.__html__;
    };
}

//inherit properties from EventListener;
MonthsInputFormController.prototype = new EventListener();





function MonthsEditFormController(date, details, status, id, callback){

    var self = this;
    this.date = date;

    // load template and register callbacks
    preLoad({'inputForm':"tabs/personal_zone/hours-report/calander_script/templates/edit_monthly-report.html"}, function(res){
        // initialize the form controller
        self.init(res);

        // inform caller that this object is ready for use
        callback();
    });
    
    /*
     * initiating the form controller
     */
    this.init = function(loaded_res){

        var html = $(loaded_res.inputForm.format({date:this.date , details: details, status: printStatus(status)}));

        // store subtree in __html__ for use by this.html()
        self.__html__ = html;

        // -----------------------
        // register event emitters
        // -----------------------
        self.id = id;
        // register on('save') event
        (html.find('#monthly-form-edit-save-button')).on('click', function(){       
        		if(validateAddMonthlyReport()) { //FUNCTION IN hourly-report/jsp_process
        			// load inputs into object & emit event
                    self.details = html.find('#hourly-form-details').val();
                    editedMonthlyReport(self);
                    
                    $('#edit_monthly-report_modal').modal('hide');
        		}
        });
        (html.find('#monthly-form-delete-button')).on('click', function(){       
    		if(validateAddMonthlyReport()) { //FUNCTION IN hourly-report/jsp_process
    			
    			// load inputs into object & emit event
                self.details = html.find('#hourly-form-details').val();
                deleteMonthlyReport(self);
                
                $('#edit_monthly-report_modal').modal('hide');
    		}
    });
    };
    
  //------------------------FORM INPUT FUNCTIONS----------------------
    function editedMonthlyReport(self) {
    	console.log("saved (monthly report)");
    	var curr_date = self.date.replace('0', '').replace('/', '-');
    	self.date = curr_date;
    	
    	console.log(self.id);
    	//EDIT MONTHLY REPORT INTO DB VIA AJAX
    	ajaxEditMonthlyReport(self);
    	
    	//INSERT MONTHLY REPORT INTO MODEL ARRAY
    	//PUSH EDITED REPORT OBJECT TO model[curr_date]
    	$(model[curr_date]).each( function() {
    		  if (this.id == self.id && this.type == 'monthly') { 
    			  this.details = self.details;
    			  this.status = 'unconfirmed';
    		  }
    		});
    	
    	//RELOAD CALANDER
    	window.setCalendar();
    }
    
    function deleteMonthlyReport(self) {
    	console.log("delete (monthly report)");
    	var curr_date = self.date.replace('0', '').replace('/', '-');
    	self.date = curr_date;
    	
    	//DELETE MONTHLY REPORT INTO DB VIA AJAX
    	ajaxDeleteMonthlyReport(self);
    	
    	//INSERT MONTHLY REPORT INTO MODEL ARRAY
     	//PUSH EDITED REPORT OBJECT TO model[curr_date]
    	for(var i in model[curr_date]){
    		  if (model[curr_date][i].id == self.id && model[curr_date][i].type == 'monthly') { 
    			  model[curr_date].splice(i, 1);
    		  }
    	}
    	
    	//RELOAD CALANDER
    	window.setCalendar();
    }
    //---------------------------------------------------------
    /*
     * return subtree for this form element
     */
    this.html = function(){
        return this.__html__;
    };
}

//inherit properties from EventListener;
MonthsInputFormController.prototype = new EventListener();




function MonthsViewFormController(date, details, status, callback) {

    var self = this;
    this.date = date;

    // load template and register callbacks
    preLoad({'inputForm':"tabs/personal_zone/hours-report/calander_script/templates/view_monthly-report.html"}, function(res){
        // initialize the form controller
        self.init(res);

        // inform caller that this object is ready for use
        callback();
    });
    
    /*
     * initiating the form controller
     */
    this.init = function(loaded_res){

        var html = $(loaded_res.inputForm.format({date:this.date , details: details, status: printStatus(status)}));

        // store subtree in __html__ for use by this.html()
        self.__html__ = html;
    };
    
    //---------------------------------------------------------
    /*
     * return subtree for this form element
     */
    this.html = function(){
        return this.__html__;
    };
}

//inherit properties from EventListener;
MonthsInputFormController.prototype = new EventListener();