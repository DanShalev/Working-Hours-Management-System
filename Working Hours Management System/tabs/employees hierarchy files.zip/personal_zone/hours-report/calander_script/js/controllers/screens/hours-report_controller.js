//ROLE IDX
role_idx = $("title").attr("name");

/*
 * get_time_diff - calculate the time difference between 2 time string
 * of the HH:MM format
 *
 * e.g get_time_diff('16:30', '08:10') -> '08:10'
 */
function get_time_diff(end_time,start_time){
    function get_total_min(time_str){
        var time_arr = time_str.split(':').map(function(x){return parseInt(x)});
        return 60*time_arr[0]+time_arr[1];
    }

    var total_time = get_total_min(end_time)-get_total_min(start_time);
    if(total_time < 0){
        return null;
    }
    return Math.floor(total_time/60)+':'+addZ(total_time % 60);
}

function printStatus(status) {
	switch (status) {
    case "unconfirmed":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"ממתין לאישור", lable:'default'});
        break;
    case "confirmed_by_manager":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"אושר (ע''י מנהל משרד)", lable:'success'});
        break;
    case "confirmed_by_president":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"אושר (ע''י עובד בנשיאות)", lable:'success'});
        break;
    case "rejected_by_manager":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"נדחה (ע''י מנהל משרד)", lable:'danger'});
        break;
    case "rejected_by_president":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"נדחה (ע''י עובד בנשיאות)", lable:'danger'});
        break;
    case "edited_by_manager":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"נערך (ע''י מנהל משרד)", lable:'warning'});
        break;
    case "edited_by_president":
        status = "<span class=\"label label-{{lable}}\">{{status}}</span>".format({status:"נערך (ע''י עובד בנשיאות)", lable:'warning'});
        break;
	}	
	
	return status;
}

function popoverClose() {
    $('.row-popover').popover('hide');
}

function popover() {
	$('[data-toggle="tooltip"]').tooltip();
	$('.row-popover').popover({html: true});

    $('.row-popover').click(function(ev){ //CLOSE ALL POPOVER BUT THIS
		ev.stopPropagation(); //PREVENT TR EVENT
	    $('.row-popover').not(this).popover('hide'); //all but this
	});
    
    return;
}
function row_converter(record){

	var date = record.date.replace(/-/g, '/');
    // fix time format
    var start_time = record.start_time;
    var end_time = record.end_time;
    var time = " {{start_time}}-{{end_time}}&nbsp;&nbsp;|&nbsp;&nbsp;{{total_time}}".format({start_time:start_time, end_time:end_time,
        total_time:get_time_diff(end_time,start_time)});

    // handle status
    var status = printStatus('unconfirmed');

    //handle popover
    var details = record.details.split('\n')[0].substr(0,45);
    if(details != record.details){
        details += '....';
        details = "<div class=\"row-popover\" data-toggle=\"popover\" data-placement=\"left\" data-container=\"body\"  data-content=\"<div style='text-align: right;'>{{fullDetails}}</div>\">{{details}}</div>".format({details: details, fullDetails:record.details});
    }

    return {date:date, time:time, status:status, details:details, id: record.id};
}
/*
 * convert server style model into manageable client side model
 */
function model_converter(model){
    var res = [];
    for(var index in model){
        var record = model[index];
        var date = record.date.replace(/-/g, '/');

        // fix time format
        var time_arr = record.time.split('-');
        var start_time = time_arr[0];
        var end_time = time_arr[1];
        var time = " {{time}}&nbsp;&nbsp;|&nbsp;&nbsp;{{total_time}}".format({time:record.time,
            total_time:get_time_diff(end_time,start_time)});

        // handle status
        var status = printStatus(record.status);

        // handle popover
        var details = record.details.split('\n')[0].substr(0,45);
        if(details != record.details){
            details += '....';
            details = "<div class=\"row-popover\" data-toggle=\"popover\" data-placement=\"left\" data-container=\"body\"  data-content=\"<div style='text-align: right;'>{{fullDetails}}</div>\">{{details}}</div>".format({details: details, fullDetails:record.details});
        }

        res.push({
            date:date,
            time:time,
            status:status,
            details:details,
            id: record.id,
            editStatus: record.editStatus
        });
    }
    return res;
}

function monthPermission(month, year) { 
	/*IF currentDAY after 2nd of month, ENABLE ONLY THIS MONTH
	IF before, ENABLE ADDING ALSO PAST MONTH*/
	var currDate = new Date();
	currDate.day = currDate.getDate();
	currDate.month = currDate.getMonth() + 1;
	currDate.year = currDate.getFullYear();
	
	return ((currDate.year == year && currDate.month == month) || //ENABLE IF CURRENT MONTH 
			(currDate.day <=2 && ((currDate.year == year && currDate.month-1 == month) || (currDate.month == 1 && currDate.year-1 == year && month == 12))));
}

function HoursReportController(callback){

    var self = this;

    var resource_d = {
        'calanderPicker':"tabs/personal_zone/hours-report/calander_script/js/components/calendarPicker.js",
        'hoursInputFormController':"tabs/personal_zone/hours-report/calander_script/js/controllers/screens/hours-form_controller.js",
        'monthlyInputFormController':"tabs/personal_zone/hours-report/calander_script/js/controllers/screens/monthly-form_controller.js",
        'add_edit':"tabs/personal_zone/hours-report/calander_script/templates/add_edit_bar.html",
        'tableRow':"tabs/personal_zone/hours-report/calander_script/templates/tableRow.html",
        'tableRowEditable':"tabs/personal_zone/hours-report/calander_script/templates/tableRowEditable.html",
        'tableRowDisabled':"tabs/personal_zone/hours-report/calander_script/templates/tableRowDisabled.html",
        'hoursReportLayout':"tabs/personal_zone/hours-report/calander_script/templates/hoursReportLayout.html"
    };

    this.records = null;

    //load template and register callbacks
    preLoad(resource_d, function(res){

        //initialize the form controller
        self.init(res);

        //inform caller that this object is ready for use
        callback();
    });



    this.init = function(res){

        var content = $('#content'); //APPLY BASIC DIVS
        content.empty();
        content.append(res.hoursReportLayout);
        var curr_model = null;

        var calendarPicker = new CalenderPicker({can_change_month:function(date){
            return (new Date() > new Date(date.year,date.month-1));
        }}, function(){ //calendarPicker CALLBACK

        	//SET DATE COLOR
        	window.setCalendar = function setCalendar(){
                var curr_date = (calendarPicker.calendar.month+'-'+calendarPicker.calendar.year);
                curr_model = model[curr_date];
                
                //MONTHLY-REPORT BUTTON
                $("#calander_monthly-report").removeClass('calendar-disabled-button m-green-color m-red-color m-yellow-color m-gray-color').empty();
                
                if (monthPermission(calendarPicker.calendar.month, calendarPicker.calendar.year))
                	$("#calander_monthly-report").html('<span class=\"glyphicon glyphicon-plus\">');
                else
                	$("#calander_monthly-report").addClass('calendar-disabled-button');
                
                //CLEAR ALL DAYS COLOR CLASS
                var n = 1;
                do {
                	$("#__calendar__-"+n).removeClass('unclickable-color green-color red-color gray-color yellow-color').addClass("default-color");
                	n++;
                } while ($("#__calendar__-"+n).length != 0);
                
                //ADD DAYS COLOR CLASS
                if(curr_model) {
                    for(var i in curr_model){
                        var record = curr_model[i];
                        //MARK HOURLY REPORTS
                        if (record.type == 'hourly')
                        	calendarPicker.calendar.markColor(record.date.split("-")[0], record.status);
                        //MONTHLY-REPORT BUTTON (2)
                        else if (record.type == 'monthly')
                        	calendarPicker.calendar.markMonthlyColor(curr_date, record.status, record.editStatus);
                    }
                }
            };

            window.addRowTable = function addRowTable(oneRow){
            	oneRow = row_converter(oneRow);
            	return $(res.tableRow.format(oneRow));
            };
            /*
             *  getRowTable - return table rows out of the model
             */
            function getRowTable(model){
                var record_table = $('<table>');
                var new_model = model_converter(model);

                for (var index in new_model){
                    var record = new_model[index];
                    var record_row = $(res.tableRow.format(record));
                    record_table.append(record_row);
                }
                return record_table;
            }

            /*
             *  getRowTableEditable - return table rows out of the model
             */
            function getRowTableEditable(model){
                var record_table = $('<table>');
                var new_model = model_converter(model);

                for (var index in new_model){
                	var record = new_model[index];
                	//CHECK EDITABLITY
                	if (record.editStatus == 'only_president') {
                		record.disabled_by =  "עובד בנשיאות";
                		var record_row = $(res.tableRowDisabled.format(record));
                	} else if (record.editStatus == 'only_manager') {
                		record.disabled_by = "מנהל המשרד";
                		var record_row = $(res.tableRowDisabled.format(record));
                	} else
                		var record_row = $(res.tableRowEditable.format(record));
                	
                    record_table.append(record_row);
                }
                return record_table;
            }

            $('#hours-report-calendar-placeholder').append(calendarPicker.html());
            setCalendar();
            var add_edit_bar = $('#hours-report-bar-placeholder').append(res.add_edit);
            $('#tr-asat-edit').hide();
            $('#tr-asat-done').hide();
            
//------------------------------MONTH CHANGE----------------------------------------------------------
            calendarPicker.monthPicker.on('monthChange', function(date){
                console.log('monthChange', date);
                setCalendar();
                var curr_date = (calendarPicker.calendar.month+'-'+calendarPicker.calendar.year);
                curr_model = model[curr_date];
                $('#tr-asat-done').hide();
                $('#tr-asat-edit').hide();
                $('#hours-table-scroll').hide();
                $('#hours-report-row-table-placeholder').empty();
            });
            
//------------------------------MONTHLY REPORT CLICK----------------------------------------------------------
            calendarPicker.monthPicker.on('monthlyReportClick', function(date) {
            	console.log('monthlyReportClick', date);
            	
            	$('#tr-asat-edit').hide();
                $('#tr-asat-done').hide();
                $('#hours-table-scroll').removeClass('scrollable');
                $('#hours-table-scroll').show();
                $('#hours-report-row-table-placeholder').empty();
                
            	var curr_date = (date.month+'-'+date.year);
            	date.monthZero = addZ(date.month); //CHANGE FROM 6 TO 06 (IN hours-report/jsp_process)
            	
            	if(model[curr_date]) {
                    var records = (model[curr_date].filter(function(x){
                        return (x.type == 'monthly');
                    }));
                    
                    if(records.length > 0){ //EDIT EXISTING RECORD
                    	console.log("edit/view existing report");	
                    	
                    	if (records[0].editStatus == 'editable' && monthPermission(date.month, date.year)) { //EDIT BOX
	                    	var editMonthlyForm = new MonthsEditFormController('{{monthZero}}/{{year}}'.format(date), records[0].details, records[0].status, records[0].id, function(){
	                            $('#hours-report-row-table-placeholder').append(editMonthlyForm.html());
	                            $('#edit_monthly-report_modal').modal('show');
	                    		});
                    	} else { //VIEW BOX
                    		var viewMonthlyForm = new MonthsViewFormController('{{monthZero}}/{{year}}'.format(date), records[0].details, records[0].status, function(){
	                            $('#hours-report-row-table-placeholder').append(viewMonthlyForm.html());
	                            $('#view_monthly-report_modal').modal('show');
	                    		});
                    	}
                    } else
                    	allowMonthlyReportAdd();
            	} else
            		allowMonthlyReportAdd();
            	
            	
            	function allowMonthlyReportAdd(){ //ADD NEW RECORD IF ALLOWED 
                	if (monthPermission(date.month, date.year)) { //CHECK DATE RANGE FOR SUMBMITTING NEW REPORTS
                		//self.records = undefined;
                    	
                		var inputMonthlyForm = new MonthsInputFormController('{{monthZero}}/{{year}}'.format(date), function(){
                        $('#hours-report-row-table-placeholder').append(inputMonthlyForm.html());
                        $('#add_monthly-report_modal').modal('show');
                		});
                	}
            	}
            		
            });
            
//------------------------------DATE CLICK----------------------------------------------------------
            calendarPicker.calendar.on('dateClicked', function(date) {
            	
            	console.clear();
                console.log('dateClicked', date);

                var curr_date = (date.month+'-'+date.year);
                date.monthZero = addZ(date.month); //CHANGE FROM 6 TO 06 (IN hours-report/jsp_process)

                if(model[curr_date]){
                    var records = (model[curr_date].filter(function(x){
                        var date_arr = x.date.split('-').map(function(i){return parseInt(i)});
                        var day = date_arr[0];
                        var month = date_arr[1];
                        var year = date_arr[2];
                        return (date.year == year && date.month == month && date.day == day && x.type == 'hourly');
                    }));

                    //IF RECORD MATCH DATE IN A MONTH RECORDED
                    if(records.length > 0){
                        self.records = records;
                        $('#tr-asat-done').hide();
                        $('#tr-asat-edit').show();
                        
                        if (!monthPermission(date.month, date.year))
                        	$('#tr-asat-edit').hide();
                        
                        popoverClose();
                        $('#hours-report-row-table-placeholder').empty();
                        $('#hours-table-scroll').show();
                        $('#hours-table-scroll').addClass('scrollable');
                        $('#hours-report-row-table-placeholder').append(getRowTable(self.records));
                        
                        popover();
            			
                    } else { //IF NO DAY RECORD IN A MONTH RECORDED
                    		addReportPermission();
                    }
                } else { //NO MONTH RECORD
                		addReportPermission();
                }
                
                function addReportPermission(){ 
                	$('#tr-asat-edit').hide();
                    $('#tr-asat-done').hide();
                    $('#hours-table-scroll').removeClass('scrollable');
                    $('#hours-table-scroll').show();
                    $('#hours-report-row-table-placeholder').empty();
                	               	
	                	//CHECK DATE RANGE FOR SUMBMITTING NEW REPORTS
	                	if (monthPermission(date.month, date.year)) { //ENABLE IF before 2nd && PAST MONTH
	                		self.records = undefined;
                        
	                		var inputForm = new HoursInputFormController('{{day}}/{{monthZero}}/{{year}}'.format(date), function(){
                            $('#hours-report-row-table-placeholder').append(inputForm.html());
                            $('#add_hourly-report_modal').modal('show');
	                		});
	                	}
                } 
            });
    
//------------------------------DELETE HOURLY-REPORT----------------------------------------------------------
            function deleteReportPermission(buttonObj){ 
            	console.log("delete mode");
            	//GET RECORD DATA
            	var record = {};
            	var tr = buttonObj.parent().parent().parent();
            	record.date = tr.children(":nth-child(2)").children().text().replace(/\//g,'-');
            	record.id = tr.attr('id').substr(13);
            	record.time = tr.children(":nth-child(3)").children().text().substr(1,11);

            	var curr_month = parseInt(record.date.split('-')[1]) + '-' + record.date.split('-')[2];
            	
            	//DELETE HOURLY REPORT INTO DB VIA AJAX
            	ajaxDeleteHourlyReport(record);
            	
            	//SEARCH ARRAY AND DELETE
            	for(var i in model[curr_month]){
            		if (model[curr_month][i].date == record.date && model[curr_month][i].id == record.id/* && model[curr_month][i].time == record.time*/) {
            			model[curr_month].splice(i, 1);
            			break;
            		}
                }

            	//REFRESH CALANDER
            	window.setCalendar();
            	$('#tr-asat-edit').hide();
                $('#tr-asat-done').hide();
                $('#hours-table-scroll').removeClass('scrollable');
                $('#hours-table-scroll').show();
                $('#hours-report-row-table-placeholder').empty();
            }
            
//------------------------------EDIT HOURLY-REPORT----------------------------------------------------------
            function editHourlyReportModal(buttonObj){ 
            	//GET REPORT DATA
            	var record = {};
            	var tr = buttonObj.parent().parent().parent();
            	record.date = tr.children(":nth-child(2)").children().text();
            	record.id = tr.attr('id').substr(13);
            	
            		//DETAILS
            	if (tr.children(":nth-child(4)").find(".row-popover").length == 0) //POPOVER DOESNT EXIST
            		record.details = tr.children(":nth-child(4)").children().text();
            	else { //POPOVER EXIST
            		var popover_contant = tr.children(":nth-child(4)").find(".row-popover").attr('data-content');
            		popover_contant = popover_contant.substr(popover_contant.indexOf(">")+1);
            		popover_contant = popover_contant.slice(0,popover_contant.lastIndexOf("<"));
            		record.details = popover_contant;
            	}

            		//TIME
            	record.time = tr.children(":nth-child(3)").children().text().substr(1,11);
            	record.startHH = record.time.substr(0,2);
            	record.startMM = record.time.substr(3,2);
            	record.endHH = record.time.substr(6,2);
            	record.endMM = record.time.substr(9,2);
            	
            	record.curr_month = parseInt(record.date.split('/')[1]) + '-' + record.date.split('/')[2];

            	//APPLY EDIT MODAL
            	var editReport = new editHourReport(record, function(){
            		$('#edit_hourly-report_modal').remove();
                    $('#hours-report-row-table-placeholder').append(editReport.html());
                    $('#edit_hourly-report_modal').modal('show');
            	});
            }
            
//------------------------------HOURLY-REPORT BAR BUTTONS----------------------------------------------------------
            
            //OPEN EDIT-BAR
            $('#asat-edit-button').on('click', function(){
                console.log("edit mode");
                $('#tr-asat-edit').hide();
                $('#tr-asat-done').show();
                popoverClose();
                $('#hours-report-row-table-placeholder').empty();
                $('#hours-report-row-table-placeholder').append(getRowTableEditable(self.records));
                
                popover();
                
                //DELETE HOURLY REPORT EVENT
                $('.delete_report_button').on('click', function(){
                	var btn = $(this);
                	
                	$('#modal_confirm_delete').modal('show');
                	
                	$('#delete_hourly-report').on('click', function(){
                		deleteReportPermission(btn);
                		$('#modal_confirm_delete').modal('hide');
                	});
                });
                
                //EDIT HOURLY REPORT EVENT
                $('.edit_report_button').on('click', function(){
                	console.log("edit report");
                	
                	var btn = $(this);
                	editHourlyReportModal(btn);
                });
            });
            
            //CLOSE EDIT BAR
            $('#asat-done-button').on('click', function(){
            	popoverClose();
                $('#tr-asat-edit').show();
                $('#tr-asat-done').hide();
                $('#hours-report-row-table-placeholder').empty();
                $('#hours-report-row-table-placeholder').append(getRowTable(self.records));
                popover();
            });

            //ADD REPORT FROM EXISTING REPORTS PANEL
            $('#asat-add-button').on('click', function(){
                console.log("add mode");
                popoverClose();
                var inputForm2 = new HoursInputFormController(self.records[0].date.replace(/-/g,'/'), function(){
                	$('#add_hourly-report_modal').remove();
                	$('#hours-report-row-table-placeholder').append(inputForm2.html());
                    $('#add_hourly-report_modal').modal('show');
                });
            });

        });
    };
}

/*EXECUTE & PRINT CALENDAR*/
var r = new HoursReportController(function(){
    console.log("Calendar ready...");
});