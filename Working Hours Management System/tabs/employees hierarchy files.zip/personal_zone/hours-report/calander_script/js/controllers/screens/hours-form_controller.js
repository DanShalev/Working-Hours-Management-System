/**
 * HoursInputFormController - controller for hourly input form
 * @param date - the form date ( predefined )
 * @param callback - this callback will be call when the controller is ready
 * @constructor
 */
function HoursInputFormController( date, callback ){

    var self = this;
    this.date = date;

    // load template and register callbacks
    preLoad({'inputForm':"tabs/personal_zone/hours-report/calander_script/templates/add_hourly-report.html"}, function(res){
        // initialize the form controller
        self.init(res);

        // inform caller that this object is ready for use
        callback();
    });
    
    /*
     * initiating the form controller
     */
    this.init = function(loaded_res){

        var html = $(loaded_res.inputForm.format({date:this.date}));

        // store subtree in __html__ for use by this.html()
        self.__html__ = html;

        // -----------------------
        // register event emitters
        // -----------------------

        // register on('cancel') event
        /*(html.find('#hourly-form-cancel-button')).on('click', function(){
            //self.emit('cancel');
        	canceledReport();
        });*/

        // register on('save') event
        (html.find('#hourly-form-add-save-button')).on('click', function(){       
        		if(validateAddHourlyReport()) { //FUNCTION IN hourly-report/jsp_process
        			// load inputs into object & emit event
                    self.start_time = html.find('#hourly-form-start-time-hh').val()+':'+
                        html.find('#hourly-form-start-time-mm').val();

                    self.end_time = html.find('#hourly-form-end-time-hh').val()+':'+
                        html.find('#hourly-form-end-time-mm').val();
                    self.id = "?";
                    self.details = html.find('#hourly-form-details').val();
                    savedHourlyReport(self);
                    
                    $('#add_hourly-report_modal').modal('hide');
        		}

        });
    };


    /*
     * return subtree for this form element
     */
    this.html = function(){
        return this.__html__;
    };
}

// inherit properties from EventListener;
HoursInputFormController.prototype = new EventListener();

//------------------------FORM INPUT FUNCTIONS----------------------
function savedHourlyReport(self) {
	console.log("saved - add new hourly report");
	//ADD HOURLY REPORT INTO DB VIA AJAX
	var id = ajaxAddHourlyReport(self);

	//INSERT MONTHLY REPORT INTO MODEL ARRAY
	var curr_date = self.date.replace(/\//g , "-");
	curr_date = curr_date.split('-')[1]+ '-' +curr_date.split('-')[2];
	curr_date = curr_date.replace('0', '');

	if (!model[curr_date]) //ADD [curr_date] TO model IF NOT EXIST
		model[curr_date] = [];

	//PUSH NEW REPORT OBJECT TO model[curr_date]
	model[curr_date].push({type:'hourly', id: id, date: self.date.replace(/\//g , "-"), status:'unconfirmed', editStatus:'editable', time:self.start_time+'-'+self.end_time, details: self.details});
    
	console.log(model[curr_date]);
	//RELOAD CALANDER
	$('#hours-report-row-table-placeholder tbody').append(window.addRowTable(self));
	window.setCalendar();
    
	popover();
}



function editHourReport (record, callback) {

    var self = this;

    // load template and register callbacks
    preLoad({'inputForm':"tabs/personal_zone/hours-report/calander_script/templates/edit_hourly-report.html"}, function(res){
        // initialize the form controller
        self.init(res);

        // inform caller that this object is ready for use
        callback();
    });
    
    /*
     * initiating the form controller
     */
    this.init = function(loaded_res){

        var html = $(loaded_res.inputForm.format({date: record.date, startHH:record.startHH,startMM:record.startMM,endHH:record.endHH,endMM:record.endMM, details:record.details, id:record.id}));

        // store subtree in __html__ for use by this.html()
        self.__html__ = html;


        // register on('save') event
       (html.find('#hourly-form-edit-button')).on('click', function(){       
        		if(validateAddHourlyReport()) { //FUNCTION IN hourly-report/jsp_process
        			//load inputs into object & emit event
        			self.date = record.date;
        			self.curr_month = record.curr_month;
        			
                    self.start_time = html.find('#hourly-form-start-time-hh').val()+':'+
                        html.find('#hourly-form-start-time-mm').val();

                    self.end_time = html.find('#hourly-form-end-time-hh').val()+':'+
                        html.find('#hourly-form-end-time-mm').val();
                    self.id = record.id;
                    self.details = html.find('#hourly-form-details').val();
                    
                    editHourlyReport(self);
                    $('#edit_hourly-report_modal').modal('hide');//.remove();
        		}

        });
        
        //edit_hourly-report_modal empty
    };


    /*
     * return subtree for this form element
     */
    this.html = function(){
        return this.__html__;
    };
}

// inherit properties from EventListener;
editHourReport.prototype = new EventListener();

function editHourlyReport(record) {
	console.log("saved - edit hourly report");
	//EDIT HOURLY REPORT INTO DB VIA AJAX
	ajaxEditHourlyReport(record);
	
	record.date = record.date.replace(/\//g,'-');
	//SEARCH ARRAY AND ALTER
	for (var i in model[record.curr_month]){
		if (model[record.curr_month][i].date == record.date && model[record.curr_month][i].id == record.id) {

			//CHANGE ARRAY
			model[record.curr_month][i].time = record.start_time+'-'+record.end_time;
			model[record.curr_month][i].details = record.details;
			model[record.curr_month][i].status = 'unconfirmed';
			break;
		}
    }

	//REFRESH CALANDER
	window.setTimeout(function(){
		window.setCalendar();
		$('#tr-asat-edit').hide();
	    $('#tr-asat-done').hide();
	    $('#hours-table-scroll').removeClass('scrollable');
	    $('#hours-table-scroll').show();
	    $('#hours-report-row-table-placeholder').empty();
	}, 400);
}