/**
 * Created by orish on 1/27/14.
 */

function MonthPicker(year, month, can_change_month){


    var hebrew_months = ["ינואר","פבואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"];
    var self = this;

    this.html = function(){
        return this.__html__;
    };

    this.__init__ = function(){

        // build the month picker
        var table = $("<table>");
        table.attr('id','month-picker-table');
        var tr = $("<tr>");
        table.append(tr);

        var left_td = $("<td class=\"month-picker-left\"><button class=\"hidden-button\"><span id=\"month-picker-left-glyphicon\" class=\"glyphicon glyphicon-chevron-left calendar-disabled-button\"></span></button></td>");

        var month_td = $('<td id=\"month-picker-text\"></td>');
        var month_text = $('<span id=\"month-picker-span\"></span>').html(hebrew_months[self.month-1] +' '+ self.year);
        month_td.append(month_text);

        var monthlyReportButton = $("<button class=\"hidden-button\" title=\"פירוט עשייה חודשית\"><span id=\"calander_monthly-report\" class=\"glyphicon glyphicon-comment calendar-disabled-button\"></button>");
        month_td.append(monthlyReportButton);
        
        var right_td = $("<td class=\"month-picker-right\"><button class=\"hidden-button\"><span class=\"glyphicon glyphicon-chevron-right\"></button></span></td>");
        
        monthlyReportButton.on('click', function(){
        	
            self.emit('monthlyReportClick', {year:self.year, month:self.month});
        });
        
        left_td.on('click', function(){

            var new_time = {year:self.year, month:self.month};

            new_time.month = ((new_time.month + 1 )% 13);
            if(new_time.month == 0 ){
                new_time.month++;
                new_time.year++;
            }
            if(can_change_month && !can_change_month(new_time)){
                return;
            }

            if(can_change_month && !can_change_month({year:new_time.year, month:new_time.month+1 })){
                $('#month-picker-left-glyphicon').addClass('calendar-disabled-button');
            }


            self.year = new_time.year;
            self.month = new_time.month;
            $('#month-picker-span').text(hebrew_months[self.month-1] +' ' + self.year);
           
            self.emit('monthChange', { year:self.year, month:self.month});
        });


        right_td.on('click', function(){
            $('#month-picker-left-glyphicon').removeClass('calendar-disabled-button');
            var new_time = {year:self.year, month:self.month};

            new_time.month--;
            if(new_time.month == 0 ){
                new_time.month = 12;
                new_time.year--;
            }
            if(can_change_month && !can_change_month(new_time)){
                return;
            }
            self.year = new_time.year;
            self.month = new_time.month;

            $('#month-picker-span').text(hebrew_months[self.month-1] +' ' + self.year);
            self.emit('monthChange', {year:self.year, month:self.month});
        });

        tr.append(right_td);
        tr.append(month_td);
        tr.append(left_td);

        this.__html__ = $('<div></div>').append(table);
    };

    this.year = year;
    this.month = month;
    this.__init__();
    
}

// inherit properties from EventListener;
MonthPicker.prototype = new EventListener();