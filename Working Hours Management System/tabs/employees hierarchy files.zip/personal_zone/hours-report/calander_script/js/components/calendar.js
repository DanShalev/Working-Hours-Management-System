/**
 * Created by orish on 1/25/14.
 */


/**
 *  Calender - responsible for displaying a hebrew calendar view
 *
 * @param year - the calendar year ( int )
 * @param month - the calendar month ( int ) where  1 -> January .. 12 -> December
 * @param style_class - string of the style class
 * @constructor
 */
function Calender(year, month, style_class){

    this.html = function(){
        return this.__html__;
    };

    /*
     *  init - initiating the calendar view
     *  @param callback - whenever a day is clicked the callback will fire an event
     */
    this.__init__ = function( style_class ){

        var self = this;

        // build the calendar DOM
        var calendar_div = $("<div>");
        calendar_div.addClass(style_class);
        var table = $("<table dir=\"rtl\"></table>");
        var __days_in_month  = this.__days_in_month();
        var __get_first_day  = this.__get_first_day();
        var __calendar_weeks = this.__get_calender_weeks(__days_in_month + __get_first_day);
        var header_key = ["ראשון", "שני","שלישי","רביעי","חמישי","שישי","שבת" ];
        var head = $("<thead class=\"table_header\"></thead>");
        var tr = $("<tr></tr>");
        head.append(tr);
        var row = 0;


        // build header row
        for( var key_index in header_key){
            var td = $("<td></td>");
            if( key_index != 6){
                td.addClass('cal_left_border');
            }
            td.text(header_key[key_index]);
            tr.append(td);
        }
        // push header row to the table
        table.append(head);

        // build calendar body
        for( var i = 0; i < __calendar_weeks*7; i++){
            var day = (i - __get_first_day + 1);

            if( (i % 7) == 0 ){
                var tr = $("<tr></tr>");
                table.append(tr);
                row++;
            }

            var td = $("<td></td>");
            td.addClass('cal_top_border');

            if( (i % 7 ) != 6){
                td.addClass('cal_left_border');
            }

            if( i < __get_first_day || i >= __get_first_day+__days_in_month){
                td.addClass('outer');
            } else {
                // register ids & callbacks
                if(new Date()  < new Date(year,month-1, day)){
                    td.addClass('calenar-disabled');
                } else {
	            	//DEFAULT
                    td.attr('id', '__calendar__-'+day);
                    td.addClass('inner');
                    
                  //SET NOT ALLOWED DATE WITH DIFRRENT CLASS (inner-click-disabled)
                    monthPermission(month, year) ? td.addClass('default-color') : td.addClass('unclickable-color');
                	
                	td.on('click', function(){
                        var td_id = day;
                        // emit dateClicked event
                        self.emit('dateClicked', {year:self.year,
                            month:self.month,
                            day:this.id.split('-')[1]});
                    });
                }
                td.text(day);
            }
            tr.append(td);
        }
        calendar_div.append(table);
        self.__html__ = calendar_div;
    };

    /*
     *
     */
    //MARK HOURLY REPORT COLOR
    this.markColor = function(day, status) {
    	if (status == "rejected_by_manager" || status == "rejected_by_president")
	        $('#__calendar__-'+day).removeClass('default-color unclickable-color green-color red-color gray-color yellow-color').addClass('red-color');
    	else if ((status == "edited_by_manager" || status == "edited_by_president") && !$('#__calendar__-'+day).hasClass("red-color"))
    		$('#__calendar__-'+day).removeClass('default-color unclickable-color green-color red-color gray-color yellow-color').addClass('yellow-color');
    	else if ((status == "confirmed_by_manager" || status == "confirmed_by_president") && !$('#__calendar__-'+day).hasClass("red-color") && !$('#__calendar__-'+day).hasClass("yellow-color"))
	        $('#__calendar__-'+day).removeClass('default-color unclickable-color green-color red-color gray-color yellow-color').addClass('green-color');
    	else if (status == "unconfirmed" && !$('#__calendar__-'+day).hasClass("red-color") && !$('#__calendar__-'+day).hasClass("yellow-color") && !$('#__calendar__-'+day).hasClass("green-color"))
	        $('#__calendar__-'+day).removeClass('default-color unclickable-color green-color red-color gray-color yellow-color').addClass('gray-color');   	
    };
    
    //MARK MONTHLY REPORT COLOR
    this.markMonthlyColor = function(date, status, editStatus){
        $("#calander_monthly-report").removeClass('calendar-disabled-button green-color red-color yellow-color gray-color').empty();
    	
        if (editStatus == 'editable' && monthPermission(date.split('-')[0], date.split('-')[1]))
    		$("#calander_monthly-report").html('<span class=\"glyphicon glyphicon-pencil\">');

        if (status == "confirmed_by_manager" || status == "confirmed_by_president")
        	$("#calander_monthly-report").addClass('m-green-color');
    	else if (status == "rejected_by_manager" || status == "rejected_by_president")
        	$("#calander_monthly-report").addClass('m-red-color');
    	else if (status == "edited_by_manager" || status == "edited_by_manager")
        	$("#calander_monthly-report").addClass('m-yellow-color');
    	else
        	$("#calander_monthly-report").addClass('m-gray-color');
    };

    /*
     *  days_in_month - return the number of days in this month
     *  taking care of leap years
     */
    this.__days_in_month = function(){
        return (new Date(this.year, this.month, 0).getDate());
    };

    /*
     *  get_first_day - return the day index [0,6] of first day of the month
     */
    this.__get_first_day = function(){
        return (new Date(this.year, this.month-1, 1).getDay());
    };

    /*
     * get_calendar_weeks - return the number of weeks that calendar should display
     */
    this.__get_calender_weeks =  function(days_in_month){
        return (Math.floor( days_in_month / 7 ) + (( days_in_month % 7 ) ? 1 : 0));
    };


    this.year = year;
    this.month = month;
    this.__init__(style_class);

}



// inherit properties from EventListener;
Calender.prototype = new EventListener();



