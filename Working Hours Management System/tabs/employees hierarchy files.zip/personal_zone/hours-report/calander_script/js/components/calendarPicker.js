/**
 * Created by orish on 1/28/14.
 */

function CalenderPicker(options, callback){

    // fill default options
    var curr_date = new Date();
    if(!options.year){
        options.year = curr_date.getFullYear();
    }
    if(!options.month){
        options.month = curr_date.getMonth()+1;
    }
    if(!options.style_class){
        options.style_class = 'calendar_table';
    }

    var self = this;

    var resource_d = {
        'calendar':"tabs/personal_zone/hours-report/calander_script/js/components/calendar.js",
        'monthPicker':"tabs/personal_zone/hours-report/calander_script/js/components/monthPicker.js"
    };

    // load template and register callbacks
    preLoad(resource_d, function(res){

        // initialize the form controller
        self.init(res);

        // inform caller that this object is ready for use
        callback();
    });


    this.init = function(res){
    	
        //hook up the month picker with the calendar
    	//CONTENT CALENDAR BUILD
        var calenderPickerDiv = $("<div class=\"content-calendar\">");
        calenderPickerDiv.append($("<table><tr><td id=\"month-picker-place-holder\"></td></tr><tr>" +
            "<td id=\"calendar-place_holder\"></td></tr></table>"));

        var month_picker_place_holder = calenderPickerDiv.find('#month-picker-place-holder');
        var calendar_place_holder = calenderPickerDiv.find('#calendar-place_holder');
        self.monthPicker = new MonthPicker(options.year, options.month, options.can_change_month );
        self.calendar = new Calender(options.year, options.month, options.style_class);

        month_picker_place_holder.append(self.monthPicker.html());
        calendar_place_holder.append(self.calendar.html());

        //register events
        self.monthPicker.on('monthChange', function(date) {

            if(options.can_change_month && !options.can_change_month(date)){

                return;
            }

            calendar_place_holder.empty();
            self.calendar = new Calender(date.year, date.month, options.style_class);
            calendar_place_holder.append(self.calendar.html());
        });

        self.__html__ = calenderPickerDiv;
    }

    this.html = function(){
        return self.__html__;
    }
}



// inherit properties from EventListener;
CalenderPicker.prototype = new EventListener();
