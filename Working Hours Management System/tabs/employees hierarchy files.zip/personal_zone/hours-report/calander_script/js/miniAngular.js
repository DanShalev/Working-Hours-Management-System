/**
 * Created on 1/25/14.
 */


/*
 *  preLoad - used to pre load files from the server
 *  @param loadObj - object that map names to urls. when ready each url resource will be avilable at
 *      loadObj.resource_name
 *      e.g loadObj = { my_resource:"/static_resources/my_file.txt"}
 *      after loading loadObj.my_resource will hold the content of my_file.txt or undefined if failed
 *  @param callback - this callback will be called after all of the requests are completed. the first
 *      param is an object that map resource_name to resource content
 */
function preLoad( loadObj, callback){

    // hold the result
    var res = {};

    // count requests
    var request_counter = 0;

    // call the callback when done
    function is_done(){
        if(request_counter == 0 && callback){
            callback(res);
        }
    }

    for( var request_key in loadObj){
        request_counter++;
        var key_path = loadObj[request_key];
        console.log("requesting ", key_path);
        var get_req = $.get(key_path);

        (function(key){
            get_req.success(function(data){
                request_counter--;
                res[key] = data;
                is_done();
            });
        })(request_key);

        (function(key){
            get_req.error(function(){
                console.warn("Couldn't found ", loadObj[key], arguments);
                request_counter--;
                is_done();
            });
        })(request_key);
    }
}

/*
 * EventListener - a supper class for anyone who want to implement event emitting
 */
function EventListener(){

    var self = this;

    // data structure for bookkeeping event listeners,
    // map event_name to list of listeners
    this.eventListeners = {};

    // register listener
    this.on = function(event_name, callback){
        if(!self.eventListeners[event_name]){
            self.eventListeners[event_name] = [];
        }
        self.eventListeners[event_name].push(callback);
        return self;
    };

    this.removeEventListener = function(event_name){
        delete self.eventListeners[event_name];
    };

    // emit events
    this.emit = function(event_name, obj){
        var listeners = self.eventListeners[event_name];

        if(!listeners){
            return;
        }
        for(var i = 0; i < listeners.length; i++ ){
            listeners[i](obj);
        }
    };
}

/*
 *  format - formatting a string with data object
 *
 *  e.g "hello {{myvar}}".format({myvar:"world!"}) -> "hello world!"
 */
String.prototype.format = function(keys) {
    return this.replace(/{{(\w+)}}/g, function(match, key) {
        return keys[key];
    });
};


/**
 * TimeHHValidator - responsible for validating input of type number for HH format
 * @param html - jquery tree element that holds the inputs
 * @param tag - the id of the input that needs to be validate
 * @param error_tag - the id of error msg element
 * @param next_focus - when input is ready will automatically move focus to next element
 * @constructor
 */
/*function TimeHHValidator(html, tag, error_tag, next_focus){
    // input jquery element
    var input = html.find('#'+tag);
    // error msg jquery element
    var err =  html.find('#'+error_tag);
    err.hide();

    // register keypress callback
    input.keypress( function(e){

        if(e.target.selectionStart == 0 &&  e.target.selectionEnd == 2){
            input.val("");
        }

        // reset error message
        err.html("");
        err.hide();

        var char = String.fromCharCode(e.keyCode);
        var tmp_input_val = input.val();

        // stop input if ready
        if(tmp_input_val.length >= 2){
            e.preventDefault();
            return;
        }

        // stop non numeric digits
        if((!$.isNumeric(char)) ){
            e.preventDefault();
            err.html("חייב להיות מספר");
            err.show();
            return;
        }

        // pre fill leading zero in case of 3-9
        if( tmp_input_val == "" && char > 2 ){
            input.val("0");
        }

        // prevent over 23 digits
        if(tmp_input_val.length == 1 && tmp_input_val > 2 && char > 3){
            e.preventDefault();
            err.html("שעה בטווח 0-23");
            err.show();
            return;
        }

        // done and autofocus on next element
        if(input.val().length >= 1){
            input.val(input.val()+char);
            e.preventDefault();
            $('#'+next_focus).focus();
        }
    });


    // add leading zero if needed on focus blur
    input.blur(function(){
        var tmp_input = input.val();
        if(tmp_input.length == 1){
            input.val("0"+tmp_input);
        }
    });

    this.is_valid = function(){
        return ( input.val().length == 2);
    };

    this.is_empty = function(){
        return ( input.val().length == 0);
    };

    this.error = function(msg){
        err.show();
        err.html(msg);
    };
}
*/

/**
 * TimeMMValidator - responsible for validating input of type number for MM format
 * @param html - jquery tree element that holds the inputs
 * @param tag - the id of the input that needs to be validate
 * @param error_tag - the id of error msg element
 * @param next_focus - when input is ready will automatically move focus to next element
 * @constructor
 */
/*function TimeMMValidator(html, tag, error_tag, next_focus){
    // input jquery element
    var input = html.find('#'+tag);
    // error msg jquery element
    var err =  html.find('#'+error_tag);

    // register keypress callback
    input.keypress( function(e){

        if(e.target.selectionStart == 0 &&  e.target.selectionEnd == 2){
            input.val("");
        }

        // reset error message
        err.html("");
        err.hide();

        var char = String.fromCharCode(e.keyCode);
        var tmp_input_val = input.val();

        // stop input if ready
        if(tmp_input_val.length >= 2){
            e.preventDefault();
            return;
        }

        // stop non numeric digits
        if((!$.isNumeric(char)) ){
            e.preventDefault();
            err.html("חייב להיות מספר");
            err.show();
            return;
        }

        // pre fill leading zero in case of 3-9
        if( tmp_input_val == "" && char > 5 ){
            e.preventDefault();
            err.html("דקות בטווח 0-59");
            err.show();
            return;
        }

        // done and autofocus on next element
        if(input.val().length >= 1){
            input.val(input.val()+char);
            e.preventDefault();
            $('#'+next_focus).focus();
        }
    });

    // add leading zero if needed on focus blur
    input.blur(function(){
        var tmp_input = input.val();
        if(tmp_input.length == 1){
            input.val("0"+tmp_input);
        }
    });

    this.is_valid = function(){
        return ( input.val().length == 2);
    };

    this.is_empty = function(){
        return ( input.val().length == 0);
    };

    this.error = function(msg){
        err.show();
        err.html(msg);
    };
}
*/



/*
 *  TimeHHMMValidator - responsible for validating input text for HH:MM format
 */
/*function TimeHHMMValidator(html, tag){

    this.state = 0;
    this.tag = tag;
    this.val = "";

    var err =  html.find('#'+tag+'-error');
    var input = html.find('#'+tag);
    var self = this;
    var selected = false;

    function display(){
        err.hide();
        err.html("");

        var dis = self.val.substring(0,2);
        if(dis.length > 1){
            dis += ':' + self.val.substring(2,self.val.length);
        }
        input.val(dis);
    }

    // listen for backspace events
    html.find('#'+tag).keyup( function(e){
        //e.preventDefault();
        // prevent unwanted behavior in case of selecting some chars and then backspacing
        if(selected){
            selected = false;
            display();
            err.show();
            err.html("please use backspace for deletion");
            return;
        }

        // handle backspace ( ascii 8 )
        if(e.keyCode == 8){
            console.log("|",input.val() ,"|");
            self.state--;
            if( self.state < 0 ){
                self.state = 0;
            }
            self.val = self.val.substr(0,self.val.length-1);
            display();
        }



    });

    // listen for text selection events
//    html.find('#'+tag).select(function(e){
//
//       selected = true;
//    });

    html.find('#'+tag).keypress( function(e){

        e.preventDefault();
        var char = String.fromCharCode(e.keyCode);

        var tmp = self.val+char;
        // handle more then 4 digits
        if(self.state > 3){
            return;
        }
        // make sure that a char is a number
        if(!$.isNumeric(char)){
            err.show();
            err.html("must be a number");
            return;
        }

        // make sure that hours are in range
        if(self.state == 0 && char > 2){
            self.val = '0';
            self.state++;
        }

        // autocomplite leading '0' for hours bigger then 2, that is 8 -> 08
        if( self.state == 1 && tmp > 23){
            err.show();
            err.html("hours must be in the range of 0-23");
            return;
        }
        // make sure minutes are in range
        if(self.state == 2 &&  char >= 6  || ( self.state == 3 && tmp.substr(2,tmp.length) > 59 )){
            err.show();
            err.html("minuts must be in the range of 0-59");
            return;
        }
        self.state++;
        self.val += char;
        display();
    });

    this.is_valid = function(){
        return (this.state == 4);
    }

    this.is_empty = function(){
        return (this.state == 0);
    }

    this.error = function(msg){
        err.show();
        err.html(msg);
    }
}
*/

$(window).on('hashchange', function() {
   console.log("address changered");
});










