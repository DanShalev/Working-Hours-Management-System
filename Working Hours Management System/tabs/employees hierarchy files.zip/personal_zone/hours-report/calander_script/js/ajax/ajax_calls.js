//----------------------HOURLY REPORTS----------------------
function ajaxAddHourlyReport(record) {
	console.log("addHourlyReport()");
	console.log(window.role_idx);
	$('#hourly-form-add-save-button').attr("disabled", "");
	$('#hourly-form-add-save-button').html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
	//POST AJAX
	var ajaxCall = $.ajax({
		  type: 'POST',
		  url: "tabs/personal_zone/hours-report/jsp_process/ajax/add_hourly-report.jsp",
		  data: {
			    date: record.date,
			    start_time: record.start_time,
			    end_time: record.end_time,
			    details: record.details,
			    role_idx: window.role_idx,
			  	},
		  async: false,
		  success: function(result) {
			  window.id = result.trim();
		  }
	});
	
	return window.id;
}

function ajaxEditHourlyReport(record) {
	console.log("editHourlyReport()");
	console.log(window.role_idx);
	$('#hourly-form-edit-button').attr("disabled", "");
	$('#hourly-form-edit-button').html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
	//POST AJAX
	$.ajax({
		  type: 'POST',
		  url: "tabs/personal_zone/hours-report/jsp_process/ajax/edit_hourly-report.jsp",
		  data: {
			    date: record.date,
			    start_time: record.start_time,
			    end_time: record.end_time,
			    details: record.details,
			    role_idx: window.role_idx,
			    report_id: record.id,
			  	},
		  async: false,
	});
	
	return;
}

function ajaxDeleteHourlyReport(record) {
	console.log("deleteHourlyReport()");
	console.log(window.role_idx);
	$('#delete_hourly-report').attr("disabled", "");
	$('#delete_hourly-report').html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
	//POST AJAX
	$.ajax({
		  type: 'POST',
		  url: "tabs/personal_zone/hours-report/jsp_process/ajax/delete_hourly-report.jsp",
		  data: {
			    date: record.date,
			    start_time: record.start_time,
			    end_time: record.end_time,
			    details: record.details,
			    role_idx: window.role_idx,
			    report_id: record.id,
			  	},
		  async: false,
		  success: function(result) {
				$('#delete_hourly-report').html('<span class="glyphicon glyphicon-trash"></span> מחק דיווח');
				$('#delete_hourly-report').removeAttr("disabled");
		  }
	});
	
	return;
}

//----------------------MONTHLY REPORTS----------------------
function ajaxAddMonthlyReport(record) {
	console.log("addMonthlyReport()");
	console.log(window.role_idx);
	$('#monthly-form-add-save-button').attr("disabled", "").html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
	
	//POST AJAX
	$.ajax({
		  type: 'POST',
		  url: "tabs/personal_zone/hours-report/jsp_process/ajax/add_monthly-report.jsp",
		  data: {
			    date: record.date,
			    details: record.details,
			    role_idx: window.role_idx,
			  	},
		  async: false,
		  success: function(result) {
			  window.id = result.trim();
		  } 
	});
	
	return window.id;
}

function ajaxEditMonthlyReport(record) {
	console.log("editMonthlyReport()");
	$('#monthly-form-edit-save-button').attr("disabled", "").html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
	//POST AJAX
	$.ajax({
		  type: 'POST',
		  url: "tabs/personal_zone/hours-report/jsp_process/ajax/edit_monthly-report.jsp",
		  data: {
			  	date: record.date,
			    details: record.details,
			    role_idx: window.role_idx,
			    report_id: record.id,
			  	},
		  async: false,
	});
	
	return;
}

function ajaxDeleteMonthlyReport(record) {
	console.log("deleteMonthlyReport()");
	$('#monthly-form-delete-button').attr("disabled", "").html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
	//POST AJAX
	$.ajax({
		  type: 'POST',
		  url: "tabs/personal_zone/hours-report/jsp_process/ajax/delete_monthly-report.jsp",
		  data: {
			  	date: record.date,
			    details: record.details,
			    role_idx: window.role_idx,
			    report_id: record.id,
			  	},
		  async: false,
	});
	
	return;
}