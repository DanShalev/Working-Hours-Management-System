$( document ).ready(function() { //Handler for .ready() called.
	function addZ(n){return n<10? '0'+n:''+n;} //add zero to month for input yyyy-mm

	var dateObj = new Date();
	var month = addZ(dateObj.getUTCMonth()+1);
	var year = dateObj.getUTCFullYear();

	//SET DEFULT MONTH FOR INPUT FIELDS
	$("#from_date").val(year+"-"+month);
	$("#to_date").val(year+"-"+month);
});

/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function birthDate(text_input) {
    var date = /^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
    return (date.test(text_input));
}
/*------------------PRINT REPORT VALIDATE----------------------------------------*/
function validateForm() {
	checkReportType();
	var form_submit = true;
	var from_date=document.forms["report_data"]["from_date"].value;
	var to_date=document.forms["report_data"]["to_date"].value;

	var currentTime = new Date();
    var currentYear = currentTime.getFullYear();
    var currentMonth = currentTime.getMonth()+1;
    monthNames = [ "", "ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני",
                   "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר" ];
    /*=======================from_date===============================*/
	var from_date_split = from_date.split("-"); //from_date_split[0] = YYYY from_date_split[1] = MM
	//IF from_date EMPTY:
    if (from_date==null || from_date=='') { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן תאריך.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF form_date IS FROM JAN 200 TO CURRMONTH - CURRYEAR
    else if ((from_date_split[0] < 2000 || from_date_split[0] > currentYear) ||
    		(from_date_split[1] < 1 || from_date_split[1] > 12) ||
    		(from_date_split[0] == currentYear && from_date_split[1] > currentMonth)) { 
	    	$("#sp_err1").addClass("help-block help-block_style").text('הזן תאריך בטווח ינואר 2000 - ' + monthNames[currentMonth] +" "+ currentYear + '.');
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================to_date===============================*/
	var to_date_split = to_date.split("-"); //to_date_split[0] = YYYY to_date_split[1] = MM
	//IF to_date EMPTY:
    if (to_date==null || to_date=='') { 
	    	$("#sp_err2").addClass("help-block help-block_style").text("הזן תאריך.");
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF to_date IS FROM JAN 200 TO CURRMONTH - CURRYEAR
    else if ((to_date_split[0] < 2000 || to_date_split[0] > currentYear) ||
    		(to_date_split[1] < 1 || to_date_split[1] > 12) ||
    		(to_date_split[0] == currentYear && to_date_split[1] > currentMonth)) { 
	    	$("#sp_err2").addClass("help-block help-block_style").text('הזן תאריך בטווח ינואר 2000 - ' + monthNames[currentMonth] +" "+ currentYear + '.');
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF from_date > to_date
    else if ((to_date_split[0] < from_date_split[0]) ||
    		(to_date_split[0] == from_date_split[0] && to_date_split[1] < from_date_split[1])) { 
	    	$("#sp_err2").addClass("help-block help-block_style").text('תאריך סיום החיפוש לא יכול להיות לפני תאריך תחילת החיפוש.');
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg2").removeClass("has-error has-feedback");
	        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg2").addClass("has-success has-feedback");
	    	$("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
 
	return form_submit;
}