$(document).ready(function() {
			//REDUCE TEXT TD SCRIPT
			var content = "";
			
			var length = $(".td_report_text").length;
			for (var i=0; i<length; i++) {
				var currTd = $(".td_report_text").eq(i);
				var fullText = currTd.html();
				var change_content = false;
				
				//IF THERES <br>
				var countBr = (fullText.match(/<br>/g) || []);
				if  (countBr.length != 0) {
					var brSplit = fullText.split("<br>");
					
					//IF text before 1 <br> > 85
					if (brSplit[0].length > 85) {
						content = fullText.substr(0, 70);
						change_content = true;
					}
					//IF text before <br> and after > 85
					else if (brSplit[0].length + brSplit[1].length > 85) {
						content = fullText.substr(0, 70);
						change_content = true;
					}
					//ONLY FIRST 2 ROWS
					else if (countBr.length > 1) {
						content = brSplit[0] + "<br>" +brSplit[1];
						change_content = true;
					}
				} 
				//IF (NO <br> < 85)
				else if (currTd.html().length > 85) {
					content = currTd.html().substr(0, 70);
					change_content = true;
				}
				
				//CHANGE CONTENT AND CREATE POPOVER
				if (change_content == true) {
					currTd.html('<div class="td-popover" data-container="body" data-toggle="popover" data-placement="left" data-content="        <div style=\'direction: rtl; text-align: right\'>'+fullText+'</div>     ">'
							+ content + '<strong>...</strong></div>');
					currTd.css("cursor", "pointer");
				}
			}
			
			//SHOW POPOVER-TD SCRIPT
			$(".td-popover").each(function(e) {
				var p = $(this).parent();
				if(p.is("td")) {
					$(this).css("padding", p.css("padding"));
					p.css("padding", "0 0");
				}
				$(this).tooltip({
					toggle: 'tooltip',
					placment: 'bottom'
				});
			});
			//CLOSE POPOVERS ON PANEL CHANGE
			$("a[data-toggle='collapse']").on('click', function(){
			      $(".td-popover").popover('hide');
			  });
			
			//CLOSE ALL POPOVER BUT THIS
			$('.td-popover').click(function(ev){
				ev.stopPropagation(); //PREVENT TR EVENT
			    $('.td-popover').not(this).popover('hide'); //all but this
			});
			
			$('.td-popover').popover({html: true});
			$('.td-popover').popover();
			
			//CHANGE LABELS SIZE
			$(".report_status span").css("font-size", "12px");
		});