/*------------------VALIDATE FUNCTIONS------------------------------------*/
function checkTextAndNumbers(text_input) {
    var letters = /^[0-9a-zA-Z]+$/;
    return (letters.test(text_input));
}

/*------------------ACCOUNT SET FORM VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
    var password1=document.forms["change_pass_form"]["password1"].value;
    var password2=document.forms["change_pass_form"]["password2"].value;
    var password3=document.forms["change_pass_form"]["password3"].value;
    var password2_ok = false;
    var password3_ok = false;
	
    /*=======================password1===============================*/
    //IF PASS1 IS EMPTY:
    if (password1==null || password1=='') {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err1").addClass("help-block help-block_style").text("הזן סיסמה נוכחית.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg1").addClass("has-error has-feedback");
        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF PASS1 IS NOT NUMBERS AND LETTERS:
    else if (!checkTextAndNumbers(password1)) {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err1").addClass("help-block help-block_style").text("הסיסמה יכולה להכיל אותיות לועזיות ומספרים בלבד.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg1").addClass("has-error has-feedback");
        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF PASS1 IS NOT 5-16 CHARS:
    else if (password1.length<5 || password1.length>16) {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err1").addClass("help-block help-block_style").text("הסיסמה חייבת להכיל 5-16 תווים.");
    	
    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg1").addClass("has-error has-feedback");
        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
        form_submit = false;
    }
    //GREEN MSG
    else {
    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg1").removeClass("has-error has-feedback");
        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err1").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg1").addClass("has-success has-feedback");
    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }

    //IF PASS2 IS EMPTY:
    if (password2==null || password2=='') {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err2").addClass("help-block help-block_style").text("הזן סיסמה חדשה.");
    	
    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg2").addClass("has-error has-feedback");
        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
        form_submit = false;
    }
    //IF PASS2 IS NOT NUMBERS AND LETTERS:
    else if (!checkTextAndNumbers(password2)) {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err2").addClass("help-block help-block_style").text("הסיסמה יכולה להכיל אותיות לועזיות ומספרים בלבד.");

    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg2").addClass("has-error has-feedback");
        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF PASS2 IS NOT 5-16 CHARS:
    else if (password2.length<5 || password2.length>16) {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err2").addClass("help-block help-block_style").text("הסיסמה חייבת להכיל 6-16 תווים.");

    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg2").addClass("has-error has-feedback");
        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //GREEN MSG
    else {
    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg2").removeClass("has-error has-feedback");
        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err2").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg2").addClass("has-success has-feedback");
    	$("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    	
    	password2_ok = true;
    }
    

    //IF PASS3 IS EMPTY:
    if (password3==null || password3=='') {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err3").addClass("help-block help-block_style").text("הזן שוב סיסמה חדשה.");

    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg3").addClass("has-error has-feedback");
        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF PASS3 IS NOT NUMBERS AND LETTERS:
    else if (!checkTextAndNumbers(password3)) {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err3").addClass("help-block help-block_style").text("הסיסמה יכולה להכיל אותיות לועזיות ומספרים בלבד.");

    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg3").addClass("has-error has-feedback");
        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF PASS3 IS NOT 5-16 CHARS:
    else if (password3.length<5 || password3.length>16) {
    	//ADD ERROR CLASS & MSG
    	$("#sp_err3").addClass("help-block help-block_style").text("הסיסמה חייבת להכיל 5-16 תווים.");

    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg3").addClass("has-error has-feedback");
        	$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //GREEN MSG
    else {
    	if ($("#fg3").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg3").removeClass("has-error has-feedback");
        	$("#sp3").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err3").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg3").addClass("has-success has-feedback");
    	$("#sp3").addClass("glyphicon glyphicon-ok form-control-feedback");
    	
    	password3_ok = true;
    }
    
    //IF PASS2!=PASS3
    if (password2_ok == true && password3_ok == true
    		&& password2!=password3 && !(password2==null || password2=='')
    		&& !(password3==null || password3=='')) {
    	//PASS2
    	//ADD ERROR CLASS & MSG
    	$("#fg2").addClass("has-error has-feedback");
        $("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	//PASS3
        $("#fg3").addClass("has-error has-feedback");
        $("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	$("#sp_err3").addClass("help-block help-block_style").text("הסיסמאות החדשות אינן זהות.");
        form_submit = false;
    }
    
return form_submit;
}

/*-----------------------VALIDATE PASSWORD CHANGE VIA MySQL DB--------------------------------*/
//IF DETAILS ARE INCORRECT
$(document).ready(function() {
	if (password_acc_set == "wrong") {
		//Password1
		$("#fg1").addClass("has-error has-feedback");
    	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		$("#sp_err1").addClass("help-block help-block_style").text("הסיסמה הנוכחית אינה נכונה.");
	}
});
//IF PASSWORD HAS BEEN CHANGED
$(document).ready(function() {
	if (password_acc_set == "changed") {
		$('#modal_changed_pass').modal('show');
	}
});