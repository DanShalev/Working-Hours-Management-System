$(function() { // Handler for .ready() called. //USED IN monthly-report & previous-monthly-report
	//------------------------SELECT ROLE HANDLER---------------------------------------- 
	var x = document.getElementById("select_role");
	var correct_role = -1;
	//HIDE UL_DIVS (EXCEPT FIRST)
	if (x!=null) {
		for (var i = 1; i < x.options.length; i++) {
			  $("#ul_"+ x.options[i].value).hide();
			  console.log("hide " + "#ul_"+ x.options[i].value);
			  //CHANGE INPUT NAMES to false
			  $("#ul_"+ x.options[i].value).find("#hours_description").attr("name","false");
			  $("#ul_"+ x.options[i].value).find("#hours").attr("name","false");
			  $("#ul_"+ x.options[i].value).find("#role").attr("name","false");
			  $("#ul_"+ x.options[i].value).find("#rolename").attr("name","false");
		}
	}
	
	$(".select_role_js").change(function() {
		if (correct_role != -1) 
			x = $("#ul_" + correct_role).find("#select_role").get(0); //get(0) - convert to js element

		//HIDE ALL UL_DIVS
		for (var i = 0; i < x.options.length; i++) {
			  $("#ul_"+ x.options[i].value).hide();
			  //CHANGE INPUT NAMES to false
			  $("#ul_"+ x.options[i].value).find("#hours_description").attr("name","false");
			  $("#ul_"+ x.options[i].value).find("#hours").attr("name","false");
			  $("#ul_"+ x.options[i].value).find("#role").attr("name","false");
			  $("#ul_"+ x.options[i].value).find("#rolename").attr("name","false");
		}
		//SHOW CORRECT UL_DIV
		for (var i = 0; i < x.options.length; i++) {
			if(x.options[i].selected == true){
			  $("#ul_" + x.options[i].value).show();
			//CHANGE INPUT NAMES to false
			  $("#ul_"+ x.options[i].value).find("#hours_description").attr("name","hours_description");
			  $("#ul_"+ x.options[i].value).find("#hours").attr("name","hours");
			  $("#ul_"+ x.options[i].value).find("#role").attr("name","role");
			  $("#ul_"+ x.options[i].value).find("#rolename").attr("name","rolename");
			  
			  console.log("show " + "#ul_"+ x.options[i].value);
			  correct_role = x.options[i].value;
			}
		}
		//SET CORRECT DIV SELECTION TO
		$("#ul_" + correct_role).find("#select_role").val(correct_role);
	});
});
