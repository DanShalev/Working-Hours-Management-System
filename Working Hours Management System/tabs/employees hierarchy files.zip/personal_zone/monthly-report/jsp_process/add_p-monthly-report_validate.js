/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkNumbers(text_input) {
	var letters = /^(?:[1-9]\d*|0)?(?:\.\d+)?$/;
    return (letters.test(text_input));
}

/*------------------ADD REPORT VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
    var hours = $("[name='hours']:visible").val();
	var hours_description = $("[name='hours_description']:visible").val();
	var ul = $(".ul_content_box:visible");
    /*=======================hours===============================*/
	//IF hours EMPTY:
    if (hours==null || hours=='') { 
    	ul.find('#sp_err1').addClass("help-block help-block_style").text("הזן שעות עבודה חודשיות.");
	    	
	    	if (!ul.find("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		ul.find("#fg1").addClass("has-error has-feedback");
	    		ul.find("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF hours NOT LETTERS
    else if (!checkNumbers(hours)) { 
    		ul.find("#sp_err1").addClass("help-block help-block_style").text("סך השעות חייב להכיל מספרים בלבד.");
	    	
	    	if (!ul.find("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		ul.find("#fg1").addClass("has-error has-feedback");
	    		ul.find("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF hours > 10000 && < 0
    else if (hours<0 || hours>10000 || hours.length>5) { 
    	ul.find("#sp_err1").addClass("help-block help-block_style").text("שעות העבודה חייבות להיות בטווח 0-10000.");
		
		if (!ul.find("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			ul.find("#fg1").addClass("has-error has-feedback");
			ul.find("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    } 
    //GREEN MSG
    else {
	    	if (ul.find("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		ul.find("#fg1").removeClass("has-error has-feedback");
	    		ul.find("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	    		ul.find("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	ul.find("#fg1").addClass("has-success has-feedback");
	    	ul.find("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================job_description===============================*/
    //IF hours_description>225
    if (hours_description.length>10000) { 
    	ul.find("#sp_err2").addClass("help-block help-block_style").text("פירוט עשייה חודשית יכול להכיל עד 10000 תווים.");
		
		if (!ul.find("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			ul.find("#fg2").addClass("has-error has-feedback");
			ul.find("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if (ul.find("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		ul.find("#fg2").removeClass("has-error has-feedback");
	    		ul.find("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	    		ul.find("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	ul.find("#fg2").addClass("has-success has-feedback");
	    	ul.find("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    //REPLACE NEWLINE
    if (form_submit == true) {
    	var text = ul.find(".hours-description-n_script").val();
		text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
		ul.find(".hours-description-n_script").val(text);
    }
	return form_submit;
}
