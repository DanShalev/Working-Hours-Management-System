/*----------REPLACE \n-------------*/
$(document).ready(function(){
		//REPLACE \n FOR FULL REPORTS
		var length = $(".hours-description-f_script").length; //f = FULL REPORT
		for (var i = 0; i<length; i++) {
			var text = $(".hours-description-f_script").eq(i).text();
			text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
			text = text.replace(/\r?\n/g, '</br>'); //replace \n
			$(".hours-description-f_script").eq(i).html(text);
		}
		/*REPLACE \n FOR NEW REPORTS 
		 * can be found inside form validate script*/
		//REPLACE \n FOR HYSTORY&PRINT-REPORTS REPORTS
		var length = $(".td_report_text").length; //f = FULL REPORT
		for (var i = 0; i<length; i++) {
			var text = $(".td_report_text").eq(i).text();
			text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
			text = text.replace(/\r?\n/g, '</br>'); //replace \n
			$(".td_report_text").eq(i).html(text);
		}
});