/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function checkNumbers(text_input) {
	var letters = /^(?:[1-9]\d*|0)?(?:\.\d+)?$/;
    return (letters.test(text_input));
}

/*------------------EDIT REPORT VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var hours=document.forms["edit_monthly-report_form"]["hours"].value;
	var hours_description=document.forms["edit_monthly-report_form"]["hours_description"].value;

    /*=======================hours===============================*/
	//IF hours EMPTY:
    if (hours==null || hours=='') { 
    	$('#sp_err1').addClass("help-block help-block_style").text("הזן שעות עבודה חודשיות.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	    		$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF hours NOT LETTERS
    else if (!checkNumbers(hours)) { 
    		$("#sp_err1").addClass("help-block help-block_style").text("סך השעות חייב להכיל מספרים בלבד.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	    		$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF hours > 10000 && < 0
    else if (hours<0 || hours>10000 || hours.length>5) { 
    	$("#sp_err1").addClass("help-block help-block_style").text("שעות העבודה חייבות להיות בטווח 0-10000.");
		
		if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg1").addClass("has-error has-feedback");
			$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    } 
    //GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	    		$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	    		$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================job_description===============================*/
    //IF hours_description>225
    if (hours_description.length>10000) { 
    	$("#sp_err2").addClass("help-block help-block_style").text("פירוט עשייה חודשית יכול להכיל עד 10000 תווים.");
		
		if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg2").addClass("has-error has-feedback");
			$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg2").removeClass("has-error has-feedback");
	    		$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	    		$("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg2").addClass("has-success has-feedback");
	    	$("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    }

    //REPLACE NEWLINE
    if (form_submit == true) {
    	var text = $(".hours-description-n_script").val();
		text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
		$(".hours-description-n_script").val(text);
    }
	return form_submit;
}
