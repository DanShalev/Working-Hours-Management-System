/*------------------VALIDATE FUNCTIONS----------------------------------------*/
function birthDate(text_input) {
    var date = /^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
    return (date.test(text_input));
}
function checkEmail(text_input) {
    var date = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    return (date.test(text_input));
}

/*------------------EDIT DETAILS VALIDATE----------------------------------------*/
function validateForm() {
	var form_submit = true;
	var birth_date=document.forms["edit_details_form"]["birth_date"].value;
	var email=document.forms["edit_details_form"]["email"].value;

    /*=======================email===============================*/
	//IF email EMPTY:
    if (email==null || email=='') { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן דואר אלקטרוני.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF email NOT VALID
    else if (!checkEmail(email)) { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן כתובת דואר אלקטרוני תקינה. example@mail.com");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    else {
    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg1").removeClass("has-error has-feedback");
        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
        	$("#sp_err1").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg1").addClass("has-success has-feedback");
    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================birth_date===============================*/
    var year = birth_date.split("-"); //year[0] = form year
    var currentTime = new Date();
    var currentYear = currentTime.getFullYear();
	//IF birth_date EMPTY:
    if (birth_date==null || birth_date=='') { 
	    	$("#sp_err2").addClass("help-block help-block_style").text("הזן תאריך לידה.");
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF birth_date NOT BIRTHDATE
    else if (!birthDate(birth_date)) { 
	    	$("#sp_err2").addClass("help-block help-block_style").text("תאריך לידה לא תקין. (yyyy-mm-dd)");
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF formYear < 1900 && formYear > currentYear
    else if (year[0] < 1900 || year[0] > currentYear) { 
	    	$("#sp_err2").addClass("help-block help-block_style").text('הזן שנת לידת בטווח 1900-' + currentYear + '.');
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	        	$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg2").removeClass("has-error has-feedback");
	        	$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err2").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg2").addClass("has-success has-feedback");
	    	$("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
	return form_submit;
}
