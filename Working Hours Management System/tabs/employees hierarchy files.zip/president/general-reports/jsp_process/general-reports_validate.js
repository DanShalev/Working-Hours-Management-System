$(document).ready(function() {
	//SET DATE
	function addZ(n){return n<10? '0'+n:''+n;} //add zero to month for input yyyy-mm

	var dateObj = new Date();
	var month = addZ(dateObj.getUTCMonth() == '0' ?12:dateObj.getUTCMonth());
	var year = dateObj.getUTCFullYear();

	$("#from_date").val(year+"-"+month);
	
	//HIDE DATE PICKER
	$('input[type=radio][name=report_type]').change(function() {
	    if (this.value == '3') {
	        $("#report_date_div").hide();
	        $("#main_li").css("height", "190px");
	    }
	    else {
	    	$("#report_date_div").show();
	        $("#main_li").css("height", "");
	    }
	});
	
});


function checkReportType() {
	var value = $("input[name='report_type']:checked").val();
	if(value == "1")
		$("#report_data").attr("action", "tabs/president/general-reports/monthly-general-report.jsp");
	else if (value == "2")
		$("#report_data").attr("action", "tabs/president/general-reports/undisciplined-users_report.jsp");
	else 
		$("#report_data").attr("action", "tabs/president/general-reports/floating-users_report.jsp").attr("method","POST");
}
/********************VALIDATE FORM FUNCTION**********************/
function validateForm() {
	checkReportType();
	var form_submit = true;
	var from_date=document.forms["report_data"]["from_date"].value;

	var currentTime = new Date();
    var currentYear = currentTime.getFullYear();
    var currentMonth = currentTime.getMonth()+1;
    monthNames = [ "", "ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני",
                   "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר" ];
    /*=======================from_date===============================*/
	var from_date_split = from_date.split("-"); //from_date_split[0] = YYYY from_date_split[1] = MM
	//IF from_date EMPTY:
    if (from_date==null || from_date=='') { 
	    	$("#sp_err1").addClass("help-block help-block_style").text("הזן תאריך.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF form_date IS FROM JAN 200 TO CURRMONTH - CURRYEAR
    else if ((from_date_split[0] < 2000 || from_date_split[0] > currentYear) ||
    		(from_date_split[1] < 1 || from_date_split[1] > 12) ||
    		(from_date_split[0] == currentYear && from_date_split[1] > currentMonth)) { 
	    	$("#sp_err1").addClass("help-block help-block_style").text('הזן תאריך בטווח ינואר 2000 - ' + monthNames[currentMonth] +" "+ currentYear + '.');
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
 
	return form_submit;
}