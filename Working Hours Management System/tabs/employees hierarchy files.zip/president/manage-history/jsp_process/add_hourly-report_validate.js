function addZ(n){
	return n<10? '0'+n:''+n;
	} //add zero to month for input yyyy-mm

function checkTime(text_input) {
	var letters = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
    return (letters.test(text_input));
}

function checkDate(text_input) {
	var letters = /^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
    return (letters.test(text_input));
}

function addLeadingZeroInput(elementId) {
    if ($('#'+elementId).val().length==1) 
    	$('#'+elementId).val(function(n, current){
        return "0"+current;
    }); 
}
function checkHours(text_input) { //TRUE = STRING OK
	var letters = /^[0-9]{2}$/;
	return (letters.test(text_input) && !(text_input<0 || text_input>23));
}
function checkMinutes(text_input) {
	var letters = /^[0-9]{2}$/;
	return (letters.test(text_input) && !(text_input<0 || text_input>59));
}
/*------------------ADD REPORT VALIDATE----------------------------------------*/
function validateForm() {
	//ADD LEADING ZERO
	addLeadingZeroInput("hourly-form-start-time-mm");
	addLeadingZeroInput("hourly-form-start-time-hh");
	addLeadingZeroInput("hourly-form-end-time-mm");
	addLeadingZeroInput("hourly-form-end-time-hh");
	
	//----------------------------
	
	var form_submit = true;
	var report_date = document.forms["form"]["report_date"].value;
	
	var start_hh = $("#hourly-form-start-time-hh").val();
	var start_mm = $("#hourly-form-start-time-mm").val();
	var end_hh = $("#hourly-form-end-time-hh").val();
	var end_mm = $("#hourly-form-end-time-mm").val();
	var hours_description=document.forms["form"]["hours_description"].value;
	var hours_start_checked = false;
	var hours_end_checked = false;
	
    /*=======================report_date===============================*/
	//IF report_date EMPTY:
    if (report_date==null || report_date=='') { 
	    	$("#sp_err1").text("הזן תאריך.");
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
    //IF report_date IS date
    else if (!checkDate(report_date)) { 
	    	$("#sp_err1").text('הזן תאריך תקני.');
	    	
	    	if (!$("#fg1").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg1").addClass("has-error has-feedback");
	        	$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg1").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg1").removeClass("has-error has-feedback");
	        	$("#sp1").removeClass("glyphicon glyphicon-remove form-control-feedback");
	        	$("#sp_err1").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg1").addClass("has-success has-feedback");
	    	$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    }
    
    /*=======================start_hours===============================*/
	//IF start_hours EMPTY:
    if (start_hh==null || start_hh=='' || start_mm==null || start_mm=='') { 
    	$('#sp_err2').addClass("help-block help-block_style").text("הזן שעת התחלה.");
    	
    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg2").addClass("has-error has-feedback");
    		$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF start_hours IS hours
    else if (!checkHours(start_hh) || !checkMinutes(start_mm)) {     	
	    	$('#sp_err2').addClass("help-block help-block_style").text("הזן שעת התחלה תקינה (00-59).");
	    	
	    	if (!$("#fg2").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
	    		$("#fg2").addClass("has-error has-feedback");
	    		$("#sp2").addClass("glyphicon glyphicon-remove form-control-feedback");
	    	}
	    	form_submit = false;
    }
	//GREEN MSG
    else {
    	if ($("#fg2").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg2").removeClass("has-error has-feedback");
    		$("#sp2").removeClass("glyphicon glyphicon-remove form-control-feedback");
    		$("#sp_err2").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg2").addClass("has-success has-feedback");
    	//$("#sp1").addClass("glyphicon glyphicon-ok form-control-feedback");
    	hours_start_checked = true;
    }
    
    /*=======================end_hours===============================*/
	//IF start_hours EMPTY:
    if (end_hh==null || end_hh=='' || end_mm==null || end_mm=='') { 
    	$('#sp_err3').addClass("help-block help-block_style").text("הזן שעת סיום.");
    	
    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg3").addClass("has-error has-feedback");
    		$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
    //IF start_hours IS hours
    else if (!checkHours(end_hh) || !checkMinutes(end_mm)) { 
    	$('#sp_err3').addClass("help-block help-block_style").text("הזן שעת סיום תקינה (00-59). ");
    	
    	if (!$("#fg3").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
    		$("#fg3").addClass("has-error has-feedback");
    		$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    	}
    	form_submit = false;
    }
	//GREEN MSG
    else {
    	if ($("#fg3").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
    		$("#fg3").removeClass("has-error has-feedback");
    		$("#sp3").removeClass("glyphicon glyphicon-remove form-control-feedback");
    		$("#sp_err3").removeClass("help-block help-block_style").text("");
    	}
    	//ADD OK CLASS
    	$("#fg3").addClass("has-success has-feedback");
    	//$("#sp2").addClass("glyphicon glyphicon-ok form-control-feedback");
    	hours_end_checked = true;
    }

    /*=======================hours_start > hours_end===============================*/
    if (hours_start_checked == true && hours_end_checked == true) {
    	if (end_hh<start_hh || (end_hh==start_hh && end_mm<start_mm) || (end_hh==start_hh && end_mm==start_mm)) {
    		$("#fg2").addClass("has-error has-feedback");
    		//$("#sp1").addClass("glyphicon glyphicon-remove form-control-feedback");	
    		
    		$("#sp_err3").addClass("help-block help-block_style").text("שעת ההתחלה צריכה להקדים את שעת היציאה.");
    		$("#fg3").addClass("has-error has-feedback");
    		$("#sp3").addClass("glyphicon glyphicon-remove form-control-feedback");
    		form_submit = false;
    	}
    }
    
    /*=======================hours_description===============================*/
    //IF hours_description>225
    if (hours_description.length>10000) { 
    	$("#sp_err4").addClass("help-block help-block_style").text("פירוט עשייה חודשית יכול להכיל עד 10000 תווים.");
		
		if (!$("#fg4").hasClass("has-error")) { //*IF THERE ISNT ERROR TAG
			$("#fg4").addClass("has-error has-feedback");
			$("#sp4").addClass("glyphicon glyphicon-remove form-control-feedback");
		}
		form_submit = false;
    }
	//GREEN MSG
    else {
	    	if ($("#fg4").hasClass("has-error")) { //REMOVE ERROR CLASS & MSG
	    		$("#fg4").removeClass("has-error has-feedback");
	    		$("#sp4").removeClass("glyphicon glyphicon-remove form-control-feedback");
	    		$("#sp_err4").removeClass("help-block help-block_style").text("");
	    	}
	    	//ADD OK CLASS
	    	$("#fg4").addClass("has-success has-feedback");
	    	$("#sp4").addClass("glyphicon glyphicon-ok form-control-feedback");
    }

    //REPLACE NEWLINE
    if (form_submit == true) {
    	var text = $(".hours-description-n_script").val();
		text = text.replace(/^\s+|\s+$/g, ""); //REPLACE ALL BEG & LAST SPACES TO ''
		$(".hours-description-n_script").val(text);
    }
    
	return form_submit;
}

/******************READY HANDLER**************************/
$(document).ready(function() { //Handler for .ready() called.
	var dateObj = new Date();
	var day = addZ(dateObj.getUTCDate());
	var month = addZ(dateObj.getUTCMonth()+1);
	var year = dateObj.getUTCFullYear();
	
	//SET DEFULT MONTH FOR INPUT FIELDS
	$("#report_date").val(year+"-"+month+"-"+day);
});