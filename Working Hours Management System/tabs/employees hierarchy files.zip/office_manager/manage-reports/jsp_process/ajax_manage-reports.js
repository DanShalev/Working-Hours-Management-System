$(document).ready(function() {
	/**************************MONTHLY REPORT****************************/
	/*----------IGNORE & CONFIRM MONTHLY REPORT--------------------*/
	$(".ignore_monthly-report, .confirm_monthly-report, .delete_monthly-report").click(function(ev) {
		ev.stopPropagation(); //PREVENT TR EVENT
		//CHECK WHICE BUTTON
		if ($(this).hasClass("confirm_monthly-report")) {//CONFIRM BUTTON
			var status_toSend = "confirm";
			$(this).parent().children(".ignore_monthly-report").attr("disabled", "");
		} else if ($(this).hasClass("delete_monthly-report")) { //IGNORE BUTTON
			var status_toSend = "delete";
			$(this).parent().children(".delete_monthly-report").attr("disabled", "");
		} else { //IGNORE BUTTON
			var status_toSend = "ignore";
			$(this).parent().children(".confirm_monthly-report").attr("disabled", "");
		}
		//GET REPORT ID
		var report_id = $(this).parent().parent().attr('id');
		report_id = report_id.substring(6);
		//SHOW PROCESS BAR
		var thisButton = $(this);
		$(this).html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
		//POST AJAX
		$.post("tabs/office_manager/manage-reports/jsp_process/update_report_status.jsp",
				  {
				    reportId: report_id,
				    status: status_toSend
				  },
				  function(data,status){
					  //WHEN AJAX CALL IS DONE - CHANGE BUTTON TEXT & COLOR
					  thisButton.html('<span class="glyphicon glyphicon-floppy-saved"></span> נשמר');
					  thisButton.removeClass("btn-default btn-success").addClass("btn-primary");
					  thisButton.parent().parent().delay(300).hide(500);
					  
					  setTimeout(function() {
						  thisButton.parent().parent().remove();
						  
						  //CHECK IF TABLE IS HIDDEN
						  firstTbodyTr = $("#monthly-report_table tbody").find("tr:first");
						  
						  if (firstTbodyTr.length == 0) { //MEANING ALL <tr> ARE HIDDEN, HIDE TABLE
							  $("#monthly-report_table").hide(200);
							  //CREATE NO-REPORTS MSG
							  $("#no_monthly-report_table").hide().html('<span class="search_heading"><span class="glyphicon glyphicon-list-alt"></span> אין דיווחים חודשיים המחכים לאישור.</span>');
							  $("#no_monthly-report_table").css("margin-top", "9px").css("margin-bottom", "7px").show(200);
						  }
					  
					  }, 801); //END OF SET TIMEOUT
				  });
	});
	
	/**************************HOURLY REPORT****************************/
	/*----------IGNORE & CONFIRM MONTHLY REPORT--------------------*/
	$(".ignore_hourly-report, .confirm_hourly-report, .delete_hourly-report").click(function(ev) {
		ev.stopPropagation(); //PREVENT TR EVENT
		//CHECK WHICE BUTTON
		if ($(this).hasClass("confirm_hourly-report")) {//CONFIRM BUTTON
			var status_toSend = "confirm";
			$(this).parent().children(".ignore_hourly-report").attr("disabled", "");
		} else if ($(this).hasClass("delete_hourly-report")) { //IGNORE BUTTON
			var status_toSend = "delete";
			$(this).parent().children(".delete_hourly-report").attr("disabled", "");
		} else { //IGNORE BUTTON
			var status_toSend = "ignore";
			$(this).parent().children(".confirm_hourly-report").attr("disabled", "");
		}
		//GET REPORT ID
		var report_id = $(this).parent().parent().attr('id');
		report_id = report_id.substring(6);
		//SHOW PROCESS BAR
		var thisButton = $(this);
		$(this).html('<span class="glyphicon glyphicon-floppy-save"></span> מעבד...');
		//POST AJAX
		$.post("tabs/office_manager/manage-reports/jsp_process/update_hourly-report_status.jsp",
				  {
				    reportId: report_id,
				    status: status_toSend
				  },
				  function(data,status){
					  //WHEN AJAX CALL IS DONE - CHANGE BUTTON TEXT & COLOR
					  thisButton.html('<span class="glyphicon glyphicon-floppy-saved"></span> נשמר');
					  thisButton.removeClass("btn-default btn-success").addClass("btn-primary");
					  thisButton.parent().parent().delay(300).hide(500);

					  setTimeout(function() {
						  thisButton.parent().parent().remove();
						  
						  //CHECK IF TABLE IS HIDDEN
						  firstTbodyTr = $("#hourly-report_table tbody").find("tr:first");
						  
						  if (firstTbodyTr.length == 0) { //MEANING ALL <tr> ARE HIDDEN, HIDE TABLE
							  $("#hourly-report_table").hide(200);
							  //CREATE NO-REPORTS MSG
							  $("#no_hourly-report_table").hide().html('<span class="search_heading"><span class="glyphicon glyphicon-list-alt"></span> אין דיווחים חודשיים המחכים לאישור.</span>');
							  $("#no_hourly-report_table").css("margin-top", "9px").css("margin-bottom", "7px").show(200);
						  } 

					  }, 801); //END OF SET TIMEOUT
				  });
	});
});